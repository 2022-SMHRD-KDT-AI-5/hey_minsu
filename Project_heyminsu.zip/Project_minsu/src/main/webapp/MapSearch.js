// 마커를 담을 배열입니다
var markers = [];
var mapContainer = document.getElementById('map'), // 지도를 표시할 div 
	mapOption = {
		center: new kakao.maps.LatLng(33.391430, 126.529410), // 지도의 중심좌표
		level: 10 // 지도의 확대 레벨
	};
// 지도를 생성합니다    
var map = new kakao.maps.Map(mapContainer, mapOption);
// 장소 검색 객체를 생성합니다
var ps = new kakao.maps.services.Places();
// 검색 결과 목록이나 마커를 클릭했을 때 장소명을 표출할 인포윈도우를 생성합니다
var infowindow = new kakao.maps.InfoWindow({ zIndex: 1 });
// 키워드로 장소를 검색합니다
searchPlaces();
// 키워드 검색을 요청하는 함수입니다
function searchPlaces() {
	var keyword = document.getElementById('keyword').value;
	if (!keyword.replace(/^\s+|\s+$/g, '')) {
		return true;
	}
	// 장소검색 객체를 통해 키워드로 장소검색을 요청합니다
	ps.keywordSearch(keyword, placesSearchCB);
}
// 장소검색이 완료됐을 때 호출되는 콜백함수 입니다
function placesSearchCB(data, status, pagination) {
	if (status === kakao.maps.services.Status.OK) {
		// 정상적으로 검색이 완료됐으면
		// 검색 목록과 마커를 표출합니다
		displayPlaces(data);

		// 페이지 번호를 표출합니다
		displayPagination(pagination);
	} else if (status === kakao.maps.services.Status.ZERO_RESULT) {
		alert('검색 결과가 존재하지 않습니다.');
		return;
	} else if (status === kakao.maps.services.Status.ERROR) {
		alert('검색 결과 중 오류가 발생했습니다.');
		return;
	}
}
// 검색 결과 목록과 마커를 표출하는 함수입니다
function displayPlaces(places) {
	var listEl = document.getElementById('placesList'),
		menuEl = document.getElementById('menu_wrap'),
		fragment = document.createDocumentFragment(),
		bounds = new kakao.maps.LatLngBounds(),
		listStr = '';

	// 검색 결과 목록에 추가된 항목들을 제거합니다
	removeAllChildNods(listEl);
	// 지도에 표시되고 있는 마커를 제거합니다
	removeMarker();

	for (var i = 0; i < places.length; i++) {
		// 마커를 생성하고 지도에 표시합니다
		var placePosition = new kakao.maps.LatLng(places[i].y, places[i].x),
			marker = addMarker(placePosition, i),
			itemEl = getListItem(i, places[i]); // 검색 결과 항목 Element를 생성합니다
		// 검색된 장소 위치를 기준으로 지도 범위를 재설정하기위해
		// LatLngBounds 객체에 좌표를 추가합니다
		bounds.extend(placePosition);
		// 마커와 검색결과 항목에 mouseover 했을때
		// 해당 장소에 인포윈도우에 장소명을 표시합니다
		// mouseout 했을 때는 인포윈도우를 닫습니다
		(function(marker, title) {
			kakao.maps.event.addListener(marker, 'mouseover', function() {
				displayInfowindow(marker, title);
			});
			kakao.maps.event.addListener(marker, 'mouseout', function() {
				infowindow.close();
			});
			itemEl.onmouseover = function() {
				displayInfowindow(marker, title);
			};
			itemEl.onmouseout = function() {
				infowindow.close();
			};
		})(marker, places[i].place_name);
		fragment.appendChild(itemEl);
	}
	// 검색결과 항목들을 검색결과 목록 Element에 추가합니다
	listEl.appendChild(fragment);
	menuEl.scrollTop = 0;
	// 검색된 장소 위치를 기준으로 지도 범위를 재설정합니다
	map.setBounds(bounds);
}
// 검색결과 항목을 Element로 반환하는 함수입니다
function getListItem(index, places) {
	var el = document.createElement('li'),
		itemStr = '<span class="markerbg marker_' + (index + 1) + '"></span>' +
			'<div class="info">' +
			'   <h5>' + places.place_name + '</h5>';
	if (places.road_address_name) {
		itemStr += '    <span>' + places.road_address_name + '</span>' +
			'   <span class="jibun gray">' + places.address_name + '</span>';
	} else {
		itemStr += '    <span>' + places.address_name + '</span>';
	}

	itemStr += '  <span class="tel">' + places.phone + '</span>' +
		'</div>';
	el.innerHTML = itemStr;
	el.className = 'item';
	return el;
}
// 마커를 생성하고 지도 위에 마커를 표시하는 함수입니다
function addMarker(position, idx, title) {
	var imageSrc = 'https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/marker_number_blue.png', // 마커 이미지 url, 스프라이트 이미지를 씁니다
		imageSize = new kakao.maps.Size(36, 37),  // 마커 이미지의 크기
		imgOptions = {
			spriteSize: new kakao.maps.Size(36, 691), // 스프라이트 이미지의 크기
			spriteOrigin: new kakao.maps.Point(0, (idx * 46) + 10), // 스프라이트 이미지 중 사용할 영역의 좌상단 좌표
			offset: new kakao.maps.Point(13, 37) // 마커 좌표에 일치시킬 이미지 내에서의 좌표
		},
		markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize, imgOptions),
		marker = new kakao.maps.Marker({
			position: position, // 마커의 위치
			image: markerImage
		});
	clickable = true;
	marker.setMap(map); // 지도 위에 마커를 표출합니다
	markers.push(marker);  // 배열에 생성된 마커를 추가합니다
	return marker;
}
// 지도 위에 표시되고 있는 마커를 모두 제거합니다
function removeMarker() {
	for (var i = 0; i < markers.length; i++) {
		markers[i].setMap(null);
	}
	markers = [];
}
// 검색결과 목록 하단에 페이지번호를 표시는 함수입니다
function displayPagination(pagination) {
	var paginationEl = document.getElementById('pagination'),
		fragment = document.createDocumentFragment(),
		i;
	// 기존에 추가된 페이지번호를 삭제합니다
	while (paginationEl.hasChildNodes()) {
		paginationEl.removeChild(paginationEl.lastChild);
	}
	for (i = 1; i <= pagination.last; i++) {
		var el = document.createElement('a');
		el.href = "#";
		el.innerHTML = i;
		if (i === pagination.current) {
			el.className = 'on';
		} else {
			el.onclick = (function(i) {
				return function() {
					pagination.gotoPage(i);
				}
			})(i);
		}
		fragment.appendChild(el);
	}
	paginationEl.appendChild(fragment);
}
// 검색결과 목록 또는 마커를 클릭했을 때 호출되는 함수입니다
// 인포윈도우에 장소명을 표시합니다
function displayInfowindow(marker, title) {
	var content = '<div style="padding:5px;z-index:1;">' + title + '</div>';
	infowindow.setContent(content);
	infowindow.open(map, marker);
}
// 검색결과 목록의 자식 Element를 제거하는 함수입니다
function removeAllChildNods(el) {
	while (el.hasChildNodes()) {
		el.removeChild(el.lastChild);
	}
}

// var iwContent = '<div style="padding:15px";,margin-top="px";,position="absolute";>김민수</div>',iwRemoveable = true;

// 카페 인포창에 표출될 내용
var coffee_content = ['<div class="customoverlay">' + '<a href="https://place.map.kakao.com/1315063856" target="_blank">' + '<span class="title">동명정류장</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/1241435799" target="_blank">' + '<span class="title">엘리사</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/1491888881" target="_blank">' + '<span class="title">알마커피제작소</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/371491242" target="_blank">' + '<span class="title">윤재커피</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/555396252" target="_blank">' + '<span class="title">슬랩</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/1571910152" target="_blank">' + '<span class="title">스물다섯</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/440194716" target="_blank">' + '<span class="title">순아</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/528303189" target="_blank">' + '<span class="title">그레이그로브</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/233131508" target="_blank">' + '<span class="title">카페바르941</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/1221602642" target="_blank">' + '<span class="title">카페책국자</span>' + '</a>' + '</div>',
]

// 음식점 인포창에 표출될 내용
var food_content = ['<div class="customoverlay">' + '<a href="https://place.map.kakao.com/1580890176" target="_blank">' + '<span class="title">고집돌우럭 중문점</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/471417273" target="_blank">' + '<span class="title">램앤블랙</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/1942763932" target="_blank">' + '<span class="title">갈치공장</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/1480065759" target="_blank">' + '<span class="title">하원가흑돼지</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/184274845" target="_blank">' + '<span class="title">중문흑돼지천국</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/1229834384" target="_blank">' + '<span class="title">달이뜨는식탁</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/1612962916" target="_blank">' + '<span class="title">제주선채향</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/552369116" target="_blank">' + '<span class="title">중문그때그집</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/2076904700" target="_blank">' + '<span class="title">수복강녕</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/256756454" target="_blank">' + '<span class="title">알동네집 화순점</span>' + '</a>' + '</div>',
]

// 박물관 인포창에 표출될 내용
var museum_content = ['<div class="customoverlay">' + '<a href="https://place.map.kakao.com/8192179" target="_blank">' + '<span class="title">국립제주박물관</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/7952882" target="_blank">' + '<span class="title">세계자동차피아노박물관</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/17583646" target="_blank">' + '<span class="title">박물관은살아있다 제주중문점</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/19585161" target="_blank">' + '<span class="title">제주항공우주박물관</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/26608807" target="_blank">' + '<span class="title">헬로키티아일랜드</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/8067497" target="_blank">' + '<span class="title">제주민속자연사박물관</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/1608663587" target="_blank">' + '<span class="title">피규어뮤지엄제주</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/20303776" target="_blank">' + '<span class="title">넥슨컴퓨터박물관</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/17600341" target="_blank">' + '<span class="title">해녀박물관</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/23972751" target="_blank">' + '<span class="title">감귤박물관</span>' + '</a>' + '</div>',
]

// 해수욕장 인포창에 표출될 내용
var beach_content = ['<div class="customoverlay">' + '<a href="https://place.map.kakao.com/1950858245" target="_blank">' + '<span class="title">세기알해변</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/1718571277" target="_blank">' + '<span class="title">우뭇개해안</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/11041974" target="_blank">' + '<span class="title">검멀레해변</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/13723603" target="_blank">' + '<span class="title">금능해수욕장</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/25023085" target="_blank">' + '<span class="title">김녕해수욕장</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/8640631" target="_blank">' + '<span class="title">표선해수욕장</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/25022153" target="_blank">' + '<span class="title">곽지해수욕장</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/8159415" target="_blank">' + '<span class="title">협재해수욕장</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/8148451" target="_blank">' + '<span class="title">함덕해수욕장</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/25049180" target="_blank">' + '<span class="title">신창풍차해안</span>' + '</a>' + '</div>',
]
// 테마파크 인포창에 표출될 내용
var theme_content = ['<div class="customoverlay">' + '<a href="https://place.map.kakao.com/14087877" target="_blank">' + '<span class="title" >남원용암해수풀장</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/1304746374" target="_blank">' + '<span class="title">제주포크테마파크</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/23150913" target="_blank">' + '<span class="title">휘닉스제주섭지코지 바람의언덕</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/2132173808" target="_blank">' + '<span class="title">고스트타운 고스트하우스</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/17808836" target="_blank">' + '<span class="title">이상한나라의앨리스 서광카트장</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/620485575" target="_blank">' + '<span class="title">신화테마파크 윙클스하우스</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/12706758" target="_blank">' + '<span class="title">무병장수테마파크</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/11714326" target="_blank">' + '<span class="title">제주레포츠랜드</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/17382302" target="_blank">' + '<span class="title">성읍랜드</span>' + '</a>' + '</div>',
'<div class="customoverlay">' + '<a href="https://place.map.kakao.com/11023307" target="_blank">' + '<span class="title">금능석물원</span>' + '</a>' + '</div>',
]
var bin = []
// 커피숍 마커가 표시될 좌표 배열입니다
var coffeePositions = [
	new kakao.maps.LatLng(33.39714136, 126.2662354),
	new kakao.maps.LatLng(33.4853812, 126.3899719),
	new kakao.maps.LatLng(33.49014367, 126.5273968),
	new kakao.maps.LatLng(33.51184154, 126.5241044),
	new kakao.maps.LatLng(33.39483568, 126.2416298),
	new kakao.maps.LatLng(33.48897995, 126.4807951),
	new kakao.maps.LatLng(33.51304021, 126.5227006),
	new kakao.maps.LatLng(33.22584113, 126.2998184),
	new kakao.maps.LatLng(33.43486224, 126.9163237),
	new kakao.maps.LatLng(33.5502325, 126.6947944)
];

// 음식점 마커가 표시될 좌표 배열입니다

var foodPositions = [
	new kakao.maps.LatLng(33.25797666, 126.4167028),
	new kakao.maps.LatLng(33.43679603, 126.6731134),
	new kakao.maps.LatLng(33.53190352, 126.8509609),
	new kakao.maps.LatLng(33.23977243, 126.436983),
	new kakao.maps.LatLng(33.24269553, 126.4487512),
	new kakao.maps.LatLng(33.55316921, 126.7908025),
	new kakao.maps.LatLng(33.22636176, 126.299093),
	new kakao.maps.LatLng(33.26423922, 126.3900823),
	new kakao.maps.LatLng(33.48840327, 126.4993864),
	new kakao.maps.LatLng(33.25358536, 126.3406934)
];

// 박물관 마커가 표시될 좌표 배열입니다
var museumPositions = [
	new kakao.maps.LatLng(33.51379681, 126.5479099),
	new kakao.maps.LatLng(33.28287613, 126.3496279),
	new kakao.maps.LatLng(33.25489681, 126.409767),
	new kakao.maps.LatLng(33.3037596, 126.3016193),
	new kakao.maps.LatLng(33.29009959, 126.352081),
	new kakao.maps.LatLng(33.50651201, 126.5315229),
	new kakao.maps.LatLng(33.28190307, 126.3553561),
	new kakao.maps.LatLng(33.47202077, 126.485584),
	new kakao.maps.LatLng(33.52274845, 126.8630469),
	new kakao.maps.LatLng(33.27159405, 126.6074293)
];

// 테마파크 마커가 표시될 좌표 배열입니다
var themePositions = [
	new kakao.maps.LatLng(33.27781471, 126.7196024),
	new kakao.maps.LatLng(33.40913274, 126.3895609),
	new kakao.maps.LatLng(33.42704467, 126.9322411),
	new kakao.maps.LatLng(33.47605571, 126.3571162),
	new kakao.maps.LatLng(33.28860303, 126.3216873),
	new kakao.maps.LatLng(33.30669689, 126.314351),
	new kakao.maps.LatLng(33.39519993, 126.3602893),
	new kakao.maps.LatLng(33.48219124, 126.6388102),
	new kakao.maps.LatLng(33.39849024, 126.7869814),
	new kakao.maps.LatLng(33.38562367, 126.2264615)
];

// 해수욕장 마커가 표시될 좌표 배열입니다
var beachPositions = [
	new kakao.maps.LatLng(33.55769127, 126.756348),
	new kakao.maps.LatLng(33.46710421, 126.9325961),
	new kakao.maps.LatLng(33.50770519, 126.9550808),
	new kakao.maps.LatLng(33.39040068, 126.2362052),
	new kakao.maps.LatLng(33.55710644, 126.7598385),
	new kakao.maps.LatLng(33.32403621, 126.8276385),
	new kakao.maps.LatLng(33.4502301, 126.3049021),
	new kakao.maps.LatLng(33.39384848, 126.2395602),
	new kakao.maps.LatLng(33.54282298, 126.6705076),
	new kakao.maps.LatLng(33.34523307, 126.1775667)
];



var markerImageSrc1 = './img/image_cafe.png';  // 마커이미지의 주소입니다. 스프라이트 이미지 입니다
var markerImageSrc2 = './img/image_dinning.png';  // 마커이미지의 주소입니다. 스프라이트 이미지 입니다
var markerImageSrc3 = './img/image_museum';  // 마커이미지의 주소입니다. 스프라이트 이미지 입니다
var markerImageSrc4 = './img/image_beach.png';  // 마커이미지의 주소입니다. 스프라이트 이미지 입니다
var markerImageSrc5 = './img/image_park.png';  // 마커이미지의 주소입니다. 스프라이트 이미지 입니다
var markerImageSrc6 = './img/image_delete.png';  // 마커이미지의 주소입니다. 스프라이트 이미지 입니다

coffeeMarkers = [], // 커피숍 마커 객체를 가지고 있을 배열입니다
	coffeeOverlay = [], // 커피숍 오버레이 객체를 가지고 있을 배열
	foodMarkers = [], // 음식점 마커 객체를 가지고 있을 배열입니다
	foodOverlay = [], // 음식점 오버레이 객체를 가지고 있을 배열
	museumMarkers = []; // 박물관 마커 객체를 가지고 있을 배열입니다
museumOverlay = [], // 박물관 오버레이 객체를 가지고 있을 배열
	beachMarkers = []; // 해수욕장 마커 객체를 가지고 있을 배열입니다
beachOverlay = [], // 해수욕장 오버레이 객체를 가지고 있을 배열
	themeMarkers = []; // 테마파크 마커 객체를 가지고 있을 배열입니다
themeOverlay = [], // 테마파크 오버레이 객체를 가지고 있을 배열
	coffeeinfo = []; // 커피숍 인포창 객체를 가지고 있을 배열
foodinfo = []; // 음식점 인포창 객체를 가지고 있을 배열
museuminfo = []; // 박물관 인포창 객체를 가지고 있을 배열
beachinfo = []; // 해수욕장 인포창 객체를 가지고 있을 배열
themeinfo = []; // 테마파크 인포창 객체를 가지고 있을 배열



createCoffeeMarkers(); // 커피숍 마커를 생성하고 커피숍 마커 배열에 추가합니다
createfoodMarkers(); // 음식점 마커를 생성하고 편의점 마커 배열에 추가합니다
createmuseumMarkers(); // 박물관 마커를 생성하고 주차장 마커 배열에 추가합니다
createbeachMarkers(); // 해수욕장 마커를 생성하고 주차장 마커 배열에 추가합니다
createthemeMarkers(); // 테마파크 마커를 생성하고 주차장 마커 배열에 추가합니다

changeMarker(); // 지도에 커피숍 마커가 보이도록 설정합니다    
var iwContent = [];

// 마커이미지의 주소와, 크기, 옵션으로 마커 이미지를 생성하여 리턴하는 함수입니다
function createMarkerImage(src, size, options) {
	var markerImage = new kakao.maps.MarkerImage(src, size, options);
	return markerImage;
}

// 좌표와 마커이미지를 받아 마커를 생성하여 리턴하는 함수입니다
function createMarker(position, image) {
	var marker = new kakao.maps.Marker({
		position: position,
		image: image
	});

	return marker;
}

function makeOverListener(map, marker, infowindow) {
	return function() {
		infowindow.open(map, marker);
	};
}

// 인포윈도우를 닫는 클로저를 만드는 함수입니다 
function makeOutListener(infowindow) {
	return function() {
		infowindow.close();
	};
}

listBox = [];
// 커피숍 마커를 생성하고 커피숍 마커 배열에 추가하는 함수입니다
function createCoffeeMarkers() {

	for (var i = 0; i < coffeePositions.length; i++) {

		var imageSize = new kakao.maps.Size(130, 130),
			imageOptions = {
				spriteOrigin: new kakao.maps.Point(0, 0),
				spriteSize: new kakao.maps.Size(48, 48),
				offset: new kakao.maps.Point(5, 30)
			};
		// 마커이미지와 마커를 생성합니다
		var markerImage = createMarkerImage(markerImageSrc1, imageSize, imageOptions),
			marker = createMarker(coffeePositions[i], markerImage);
		var infowindow_cafe = new kakao.maps.InfoWindow({
			// 인포윈도우가 표시될 지도
			position: coffeePositions[i], // 인포창의 위치
			content: coffee_content[i] // 인포창 내용
		});

		var customOverlay = new kakao.maps.CustomOverlay({
			position: coffeePositions[i],
			content: coffee_content[i],
			yAnchor: 1

		});
		// 생성된 마커를 커피숍 마커 배열에 추가합니다
		coffeeMarkers.push(marker);
		coffeeOverlay.push(customOverlay);

		kakao.maps.event.addListener(marker, 'click', makeOverListener(map, marker, infowindow_cafe));
		kakao.maps.event.addListener(marker, 'mouseout', makeOutListener(infowindow_cafe));
	}

}


// 커피숍 마커들의 지도 표시 여부를 설정하는 함수입니다
function setCoffeeMarkers(map) {
	for (var i = 0; i < coffeeMarkers.length; i++) {
		coffeeMarkers[i].setMap(map);
		coffeeOverlay[i].setMap(map);
	}

}



// 음식점 마커를 생성하고 음식점 마커 배열에 추가하는 함수입니다
function createfoodMarkers() {
	for (var i = 0; i < foodPositions.length; i++) {

		var imageSize = new kakao.maps.Size(130, 130),
			imageOptions = {
				spriteOrigin: new kakao.maps.Point(0, 0),
				spriteSize: new kakao.maps.Size(48, 48),
				offset: new kakao.maps.Point(5, 30)
			};
		// 마커이미지와 마커를 생성합니다
		var markerImage = createMarkerImage(markerImageSrc2, imageSize, imageOptions),
			marker = createMarker(foodPositions[i], markerImage);

		var infowindow_food = new kakao.maps.InfoWindow({
			position: foodPositions[i], // 인포창의 위치
			content: food_content[i] // 인포창 내용
		});

		var customOverlay = new kakao.maps.CustomOverlay({
			position: foodPositions[i],
			content: food_content[i],
			yAnchor: 1

		});
		// 생성된 마커를 음식점 마커 배열에 추가합니다
		foodMarkers.push(marker);
		foodOverlay.push(customOverlay);

		kakao.maps.event.addListener(marker, 'click', makeOverListener(map, marker, infowindow_food));

		kakao.maps.event.addListener(marker, 'mouseout', makeOutListener(infowindow_food));
	}
}
console.log(iwContent);

// 음식점 마커들의 지도 표시 여부를 설정하는 함수입니다
function setfoodMarkers(map) {
	for (var i = 0; i < foodMarkers.length; i++) {
		foodMarkers[i].setMap(map);
		foodOverlay[i].setMap(map);

	}
}

// 박물관 마커를 생성하고 박물관 마커 배열에 추가하는 함수입니다
function createmuseumMarkers() {
	for (var i = 0; i < museumPositions.length; i++) {

		var imageSize = new kakao.maps.Size(130, 130),
			imageOptions = {
				spriteOrigin: new kakao.maps.Point(0, 0),
				spriteSize: new kakao.maps.Size(48, 48),
				offset: new kakao.maps.Point(5, 30)
			};

		// 마커이미지와 마커를 생성합니다
		var markerImage = createMarkerImage(markerImageSrc3, imageSize, imageOptions),
			marker = createMarker(museumPositions[i], markerImage);


		var infowindow_museum = new kakao.maps.InfoWindow({
			position: museumPositions[i], // 인포창의 위치
			content: museum_content[i] // 인포창 내용
		});

		var customOverlay = new kakao.maps.CustomOverlay({
			position: museumPositions[i],
			content: museum_content[i],
			yAnchor: 1

		});
		// 생성된 마커를 박물관 마커 배열에 추가합니다
		museumMarkers.push(marker);
		museumOverlay.push(customOverlay);

		kakao.maps.event.addListener(marker, 'click', makeOverListener(map, marker, infowindow_museum));
		kakao.maps.event.addListener(marker, 'mouseout', makeOutListener(infowindow_museum));
	}
}


// 박물관 마커들의 지도 표시 여부를 설정하는 함수입니다
function setmuseumMarkers(map) {
	for (var i = 0; i < museumMarkers.length; i++) {
		museumMarkers[i].setMap(map);
		museumOverlay[i].setMap(map);

	}
}

// 해수욕장 마커를 생성하고 해수욕장 마커 배열에 추가하는 함수입니다
function createbeachMarkers() {
	for (var i = 0; i < beachPositions.length; i++) {

		var imageSize = new kakao.maps.Size(130, 130),
			imageOptions = {
				spriteOrigin: new kakao.maps.Point(0, 0),
				spriteSize: new kakao.maps.Size(48, 48),
				offset: new kakao.maps.Point(5, 30)
			};

		// 마커이미지와 마커를 생성합니다
		var markerImage = createMarkerImage(markerImageSrc4, imageSize, imageOptions),
			marker = createMarker(beachPositions[i], markerImage);

		var infowindow_beach = new kakao.maps.InfoWindow({
			position: beachPositions[i], // 인포창의 위치
			content: iwContent // 인포창 내용
		});

		var customOverlay = new kakao.maps.CustomOverlay({
			position: beachPositions[i],
			content: beach_content[i],
			yAnchor: 1

		});

		// 생성된 마커를 해수욕장 마커 배열에 추가합니다
		beachMarkers.push(marker);
		beachOverlay.push(customOverlay);
		kakao.maps.event.addListener(marker, 'click', makeOverListener(map, marker, infowindow_beach));
		kakao.maps.event.addListener(marker, 'mouseout', makeOutListener(infowindow_beach));
	}
}


// 해수욕장 마커들의 지도 표시 여부를 설정하는 함수입니다
function setbeachMarkers(map) {
	for (var i = 0; i < beachMarkers.length; i++) {
		beachMarkers[i].setMap(map);
		beachOverlay[i].setMap(map);

	}
}

// 테마파크 마커를 생성하고 테마파크 마커 배열에 추가하는 함수입니다
function createthemeMarkers() {
	for (var i = 0; i < themePositions.length; i++) {

		var imageSize = new kakao.maps.Size(130, 130),
			imageOptions = {
				spriteOrigin: new kakao.maps.Point(0, 0),
				spriteSize: new kakao.maps.Size(48, 48),
				offset: new kakao.maps.Point(5, 30)
			};

		// 마커이미지와 마커를 생성합니다
		var markerImage = createMarkerImage(markerImageSrc5, imageSize, imageOptions),
			marker = createMarker(themePositions[i], markerImage);

		var customOverlay = new kakao.maps.CustomOverlay({
			position: themePositions[i],
			content: theme_content[i],
			yAnchor: 1

		});
		var infowindow_theme = new kakao.maps.InfoWindow({
			position: themePositions[i], // 인포창의 위치
			content: iwContent // 인포창 내용
		});

		// 생성된 마커를 테마파크 마커 배열에 추가합니다
		themeMarkers.push(marker);
		themeOverlay.push(customOverlay);

		kakao.maps.event.addListener(marker, 'click', makeOverListener(map, marker, infowindow_theme));
		kakao.maps.event.addListener(marker, 'mouseout', makeOutListener(infowindow_theme));
	}
}




// 테마파크 마커들의 지도 표시 여부를 설정하는 함수입니다
function setthemeMarkers(map) {
	for (var i = 0; i < themeMarkers.length; i++) {
		themeMarkers[i].setMap(map);
		themeOverlay[i].setMap(map);

	}
}



// 카테고리를 클릭했을 때 type에 따라 카테고리의 스타일과 지도에 표시되는 마커를 변경합니다
function changeMarker(type) {

	var coffeeMenu = document.getElementById('coffeeMenu');
	var storeMenu = document.getElementById('foodMenu');
	var carparkMenu = document.getElementById('museumMenu');
	var carparkMenu = document.getElementById('beach');
	var carparkMenu = document.getElementById('theme');
	var bin_click = document.getElementById('bin');
	// 커피숍 카테고리가 클릭됐을 때
	if (type === 'coffee') {

		// 커피숍 카테고리를 선택된 스타일로 변경하고
		coffeeMenu.className = 'menu_selected';

		// 편의점과 주차장 카테고리는 선택되지 않은 스타일로 바꿉니다
		foodMenu.className = '';
		museumMenu.className = '';
		beach.className = '';
		theme.className = '';

		// 커피숍 마커들만 지도에 표시하도록 설정합니다
		setCoffeeMarkers(map);
		setfoodMarkers(null);
		setmuseumMarkers(null);
		setbeachMarkers(null);
		setthemeMarkers(null);


	}
	else if (type === 'food') { // 음식점 카테고리가 클릭됐을 때

		// 음식점 카테고리를 선택된 스타일로 변경하고
		coffeeMenu.className = '';
		foodMenu.className = 'menu_selected';
		museumMenu.className = '';
		beach.className = '';
		theme.className = '';
		// 음식점 마커들만 지도에 표시하도록 설정합니다
		setCoffeeMarkers(null);
		setfoodMarkers(map);
		setmuseumMarkers(null);
		setbeachMarkers(null);
		setthemeMarkers(null);

	} else if (type === 'museum') { // 박물관 카테고리가 클릭됐을 때

		// 박물관 카테고리를 선택된 스타일로 변경하고
		coffeeMenu.className = '';
		foodMenu.className = '';
		museumMenu.className = 'menu_selected';
		beach.className = '';
		theme.className = '';

		// 박물관 마커들만 지도에 표시하도록 설정합니다
		setCoffeeMarkers(null);
		setfoodMarkers(null);
		setmuseumMarkers(map);
		setbeachMarkers(null);
		setthemeMarkers(null);
	} else if (type === 'beach') { // 해수욕장 카테고리가 클릭됐을 때

		// 해수욕장 카테고리를 선택된 스타일로 변경하고
		coffeeMenu.className = '';
		foodMenu.className = '';
		museumMenu.className = '';
		beach.className = 'menu_selected';
		theme.className = '';

		// 해수욕장 마커들만 지도에 표시하도록 설정합니다
		setCoffeeMarkers(null);
		setfoodMarkers(null);
		setmuseumMarkers(null);
		setbeachMarkers(map);
		setthemeMarkers(null);
	} else if (type === 'theme') { // 테마파크 카테고리가 클릭됐을 때

		// 테마파크 카테고리를 선택된 스타일로 변경하고
		coffeeMenu.className = '';
		foodMenu.className = '';
		museumMenu.className = '';
		beach.className = '';
		theme.className = 'menu_selected';

		// 테마파크 마커들만 지도에 표시하도록 설정합니다
		setCoffeeMarkers(null);
		setfoodMarkers(null);
		setmuseumMarkers(null);
		setbeachMarkers(null);
		setthemeMarkers(map);
	} else if (type === 'bin') {
		coffeeMenu.className = '';
		foodMenu.className = '';
		museumMenu.className = '';
		beach.className = '';
		theme.className = '';

		setCoffeeMarkers(null);
		setfoodMarkers(null);
		setmuseumMarkers(null);
		setbeachMarkers(null);
		setthemeMarkers(null);
	}




}
var btn = document.getElementsByClassName('btn');

function MapBtn() {
	customoverlay.style(display = "none");
}

kakao.maps.event.addListener(marker, 'click', function() {
	// 마커 위에 인포윈도우를 표시합니다
	alert('asdsa')
});

$(document).ready(function() {
	$('.')
})


function coffeeBox() {
	$('.box').hide();
	$("#placesList li").hide();
	$("#pagination").hide();
	$('#coffee_box').show();
}
function foodBox() {
	$('.box').hide();
	$("#placesList li").hide();
	$("#pagination").hide();
	$('#food_box').show();
}
function themeBox() {
	$('.box').hide();
	$("#placesList li").hide();
	$("#pagination").hide();
	$('#theme_box').show();
}
function museumBox() {
	$('.box').hide();
	$("#placesList li").hide();
	$("#pagination").hide();
	$('#museum_box').show();
}
function beachBox() {
	$('.box').hide();
	$("#placesList li").hide();
	$("#pagination").hide();
	$('#beach_box').show();
}
function binBox() {
	$('.box').hide();
}
function inputBox() {
	$('.box').hide();
	$("#pagination").show();
}


