var slides = document.getElementsByClassName('intro_bg'),
    slideIndex = 0;

var myVar;

showSlides();
function showSlides(){
    for(var i=0; i<slides.length; i++){
        slides[i].style.display = 'none';
    }
    slideIndex++;

    if(slideIndex > slides.length){slideIndex = 1;}

    slides[slideIndex-1].style = 'block';

    myVar = setTimeout(showSlides, 5000);
}// showSlide