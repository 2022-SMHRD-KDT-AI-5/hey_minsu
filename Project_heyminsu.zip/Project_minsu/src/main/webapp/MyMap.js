var mapContainer = document.getElementById('map'), // 지도를 표시할 div  
	mapOption = {
		center: new kakao.maps.LatLng(33.450701, 126.570667), // 지도의 중심좌표
		level: 10   // 지도의 확대 레벨
	};
var map = new kakao.maps.Map(mapContainer, mapOption); // 지도를 생성합니다
const name = ["카페콜라"]
var lng = [33.49207678]
var lat = [126.5426882]
var url = []
var mapmarker = []
var mapoverlay = []
var posi = {}
var position = []
var marker;
var list = [];

/*Mapping() 이후 적용 완료 *확인 필요* */
function MappingAdd(data){
	list = data;
	alert('성공');
}

for (var i = 0; i < list.length; i++) {
		position.push(new kakao.maps.LatLng(list[i][2], list[i][3]));
}

for (var i = 0; i < name.length; i++) {
	posi.content = '<div class="customoverlay">' +
		' <a href=' + url[i] + '>' +
		' <span class="title">' + name[i] + '</span>' +
		' </a>' +
		' </div>';
	/*    posi.latlng = new kakao.maps.LatLng(lng[i],lat[i]);
		position.push({...posi});*/
}
for (var i = 0; i < position.length; i++) {
	// 마커를 생성합니다
	marker = new kakao.maps.Marker({
		map: map, // 마커를 표시할 지도
		position: position[i].latlng // 마커의 위치
	});

	// 마커에 표시할 커스텀오버레이를 생성합니다 
	var overlay = new kakao.maps.CustomOverlay({
		map: map,
		position: position[i].latlng,
		content: position[i].content, // 인포윈도우에 표시할 내용
		yAnchor: 1
	});
	// kakao.maps.event.addListener(marker, 'click', makeOverListener(map, marker, overlay));
}

function makeOverListener(map, marker, overlay) {
	return function() {
		overlay.open(map, marker);
	};
}
marker.click

function displayPlaces() {
	var listEl = document.getElementById('placesList');

	listEl.appendChild();
}
// function getListItem(index, places) {
//     var el = document.createElement('li'),
//     itemStr = '<span class="markerbg marker_' + (index+1) + '"></span>' +
//                 '<div class="info">' +
//                 '   <h5>' + places.place_name + '</h5>';
//     if (places.road_address_name) {
//         itemStr += '    <span>' + places.road_address_name + '</span>' +
//                     '   <span class="jibun gray">' +  places.address_name  + '</span>';
//     } else {
//         itemStr += '    <span>' +  places.address_name  + '</span>'; 
//     }

//       itemStr += '  <span class="tel">' + places.phone  + '</span>' +
//                 '</div>';           
//     el.innerHTML = itemStr;
//     el.className = 'item';
//     return el;
// }


/*$('.i').click(() => {
	$('.customoverlay > a').css('background', 'pink');
});

$('#map>div>div>div>div').click(function() {
	$("#map>div>div>div>div").hide()
});*/


