drop table mem_info cascade constraint;
drop table board cascade constraint;
drop table mem_map cascade constraint;
drop table mem_like cascade constraint;
drop sequence mem_like_seq;
drop sequence mem_id_seq;
drop sequence board_num_seq;

create table mem_info(
	mem_num number(20),
	mem_id varchar2(10),
	mem_pw varchar2(10) not null,
	mem_name varchar2(10) not null,
	mem_email varchar2(10) not null,
	constraint meminfo_memnumid_pk primary key(mem_num, mem_id)
	);
	
create table mem_like(
	like_num number(20),
	mem_num number(20),
	mem_id varchar2(10),
	point varchar2(100) not null,
	like_check number(4) not null,
	constraint memlike_likenum_pk primary key(like_num),
	constraint memlike_memnum_fk foreign key(mem_num, mem_id) references mem_info(mem_num, mem_id),
	constraint memlike_likecheck_ck check(like_check in(0,1))
	);

create table board(
	board_num number(20) not null,
	mem_num number(20),
	mem_id varchar2(10),
	board_title varchar2(100) not null,
	board_content varchar2(500) not null,
	board_date date default sysdate,
	user_admin number(2) not null,
	constraint board_memnum_fk foreign key(mem_num, mem_id) references mem_info(mem_num, mem_id),
	constraint board_useradmin_ck check (user_admin in(0,1))
	);

create table mem_map(
	mem_num number(20) not null,
	mem_id varchar2(10),
	map_lat varchar2(50) not null,
	map_lng varchar2(50) not null,
	point varchar2(20) not null,
	url varchar2(100) not null,
	constraint memmap_memnum_fk foreign key(mem_num, mem_id) references mem_info(mem_num, mem_id)
	);

create sequence	mem_num_seq
		increment by 1
		start with 1
		nocache
		nocycle;
		
create sequence	board_num_seq
		increment by 1
		start with 10000
		nocache
		nocycle;

create sequence	mem_like_seq
		increment by 1
		start with 20000
		nocache
		nocycle;

		
// 임시 DB용
drop table mem_info cascade constraint;
drop table mem_map cascade constraint;
drop table mem_like cascade constraint;
drop table mem_hate cascade constraint;
drop table board cascade constraint;
drop table category cascade constraint;
drop table cafe cascade constraint;
drop table resto cascade constraint;
drop table themepark cascade constraint;
drop table horseriding cascade constraint;
drop table beach cascade constraint;
drop table museum cascade constraint;
drop table cavern cascade constraint;
drop sequence mem_num_seq;
drop sequence board_num_seq;
drop sequence mem_like_seq;
drop sequence mem_id_seq;

create table mem_info(
	mem_num number(20),
	mem_id varchar2(10),
	mem_pw varchar2(10) not null,
	mem_name varchar2(10) not null,
	mem_email varchar2(10) not null,
	constraint meminfo_memnumid_pk primary key(mem_num, mem_id)
	);

create table category(
mbti_ie varchar2(4),
mbti_ns varchar2(4),
mbti_ft varchar2(4),
mbti_pj varchar2(4),
sleep varchar2(100),
days varchar2(100),
season varchar2(100),
theme varchar2(100),
location varchar2(100),
point varchar2(100),
constraint category_point_pk primary key(point)
);

create table mem_map(
	mem_num number(20) not null,
	mem_id varchar2(10),
	map_lat varchar2(50) not null,
	map_lng varchar2(50) not null,
	point varchar2(20) not null,
	url varchar2(100) not null,
	constraint memmap_memnum_fk foreign key(mem_num, mem_id) references mem_info(mem_num, mem_id)
	);

create table mem_like(
	like_num number(20),
	mem_num number(20),
	mem_id varchar2(10),
	point varchar2(100) not null,
	like_check number(4) not null,
	constraint memlike_likenum_pk primary key(like_num),
	constraint memlike_memnum_fk foreign key(mem_num, mem_id) references mem_info(mem_num, mem_id),
	constraint memlike_likecheck_ck check(like_check in(0,1))
	);

create table mem_hate(
mem_num number(20) not null,
mem_id varchar2(10),
point varchar2(100),
constraint memhate_memnum_fk foreign key(mem_num, mem_id) references mem_info(mem_num, mem_id),
constraint memhate_point_fk foreign key(point) references category(point));

create table board(
	board_num number(20) not null,
	mem_num number(20),
	mem_id varchar2(10),
	board_title varchar2(100) not null,
	board_content varchar2(500) not null,
	board_date date default sysdate,
	user_admin number(2) not null,
	constraint board_memnum_fk foreign key(mem_num, mem_id) references mem_info(mem_num, mem_id),
	constraint board_useradmin_ck check (user_admin in(0,1))
	);

create table cafe(
	cafe_category varchar2(30) not null,
	cafe_name varchar2(50) not null,
	cafe_score varchar2(20),
	cafe_lat varchar2(20) not null,
	cafe_lng varchar2(20) not null,
	cafe_url varchar2(50)
	);

create table resto(
	resto_category varchar2(30) not null,
	resto_name varchar2(50) not null,
	resto_score varchar2(20),
	resto_lat varchar2(20) not null,
	resto_lng varchar2(20) not null,
	resto_url varchar2(50) not null
	);

create table themepark(
	themepark_category varchar2(30) not null,
	themepark_name varchar2(50) not null,
	themepark_score varchar2(20),
	themepark_lat varchar2(20) not null,
	themepark_lng varchar2(20) not null,
	themepark_url varchar2(50)
	);

create table horseriding(
	horseriding_category varchar2(30) not null,
	horseriding_name varchar2(50) not null,
	horseriding_score varchar2(20),
	horseriding_lat varchar2(20) not null,
	horseriding_lng varchar2(20) not null,
	horseriding_url varchar2(50)
	);

create table beach(
	beach_category varchar2(30) not null,
	beach_name varchar2(50) not null,
	beach_score varchar2(20),
	beach_lat varchar2(20) not null,
	beach_lng varchar2(20) not null,
	beach_url varchar2(50)
	);

create table museum(
	museum_category varchar2(30) not null,
	museum_name varchar2(50) not null,
	museum_score varchar2(20),
	museum_lat varchar2(20) not null,
	museum_lng varchar2(20) not null,
	museum_url varchar2(50)
	);

create table cavern(
	cavern_category varchar2(30) not null,
	cavern_name varchar2(50) not null,
	cavern_score varchar2(20),
	cavern_lat varchar2(20) not null,
	cavern_lng varchar2(20) not null,
	cavern_url varchar2(50)
	);

create sequence	mem_num_seq
		increment by 1
		start with 1
		nocache
		nocycle;
		
create sequence	board_num_seq
		increment by 1
		start with 10000
		nocache
		nocycle;

create sequence	mem_like_seq
		increment by 1
		start with 20000
		nocache
		nocycle;

drop table total cascade constraint;

create table total(
	name varchar2(50) not null,
	lat varchar2(50) not null,
	lng varchar2(50) not null,
	url varchar2(50)
	);
		
insert into total values('카페라라라','126.8579775','33.52486772','https://place.map.kakao.com/734323672');
insert into total values('원앤온리','126.3191923','33.23922624','https://place.map.kakao.com/217787831');
insert into total values('델문도','126.6687138','33.54370836','https://place.map.kakao.com/26867476');
insert into total values('퍼시픽리솜 더클리프카페&펍','126.4147052','33.24425774','https://place.map.kakao.com/1378746048');
insert into total values('우무','126.2564364','33.40588888','https://place.map.kakao.com/1152497778');
insert into total values('카페나모나모','126.4719499','33.50890219','https://place.map.kakao.com/373077516');
insert into total values('애월더선셋','126.3087146','33.45582708','https://place.map.kakao.com/27149644');
insert into total values('카페루시아 본점','126.3636772','33.23498107','https://place.map.kakao.com/27122037');
insert into total values('유동커피','126.5637916','33.24454148','https://place.map.kakao.com/21160031');
insert into total values('바다다','126.4374','33.23712997','https://place.map.kakao.com/1983315941');
insert into total values('베케','126.6049748','33.26195705','https://place.map.kakao.com/1191128222');
insert into total values('드르쿰다 in성산','126.9190853','33.44451143','https://place.map.kakao.com/795878887');
insert into total values('목장카페드르쿰다','126.7698644','33.40879019','https://place.map.kakao.com/1176884672');
insert into total values('울트라마린','126.206066','33.36942774','https://place.map.kakao.com/1915903142');
insert into total values('하이엔드제주','126.3092866','33.46396531','https://place.map.kakao.com/1157356606');
insert into total values('휴일로','126.3665294','33.23222229','https://place.map.kakao.com/979505096');
insert into total values('테라로사 서귀포점','126.6187935','33.24946668','https://place.map.kakao.com/25161792');
insert into total values('앙뚜아네트 용담점','126.5089881','33.5160654','https://place.map.kakao.com/915825806');
insert into total values('명월국민학교','126.2648453','33.3888988','https://place.map.kakao.com/262900404');
insert into total values('오르다','126.9351421','33.46911542','https://place.map.kakao.com/1820359262');
insert into total values('새빌','126.363384','33.36270879','https://place.map.kakao.com/2113185266');
insert into total values('몽상드애월','126.3092417','33.46292103','https://place.map.kakao.com/27114938');
insert into total values('뷰스트','126.3034789','33.2277772','https://place.map.kakao.com/1971639400');
insert into total values('커피템플','126.5701901','33.47795017','https://place.map.kakao.com/99092488');
insert into total values('카페서연의집','126.6555662','33.26943073','https://place.map.kakao.com/19639423');
insert into total values('보롬왓카페','126.7524975','33.41349866','https://place.map.kakao.com/6325127');
insert into total values('카페라라라','126.8579775','33.52486772','https://place.map.kakao.com/734323672');
insert into total values('앤트러사이트 제주한림점','126.2579773','33.40783771','https://place.map.kakao.com/26792996');
insert into total values('아줄레주','126.8393196','33.36685513','https://place.map.kakao.com/2003360746');
insert into total values('로빙화','126.7092603','33.27511896','https://place.map.kakao.com/1658038483');
insert into total values('외도339','126.4317025','33.4937367','https://place.map.kakao.com/104832990');
insert into total values('클랭블루','126.1773139','33.34487177','https://place.map.kakao.com/1313144249');
insert into total values('카페이피엘','126.6570071','33.27520972','https://place.map.kakao.com/1546271016');
insert into total values('카페록록','126.8789467','33.528862','https://place.map.kakao.com/292093583');
insert into total values('도렐 제주본점','126.9185624','33.45000531','https://place.map.kakao.com/1375299538');
insert into total values('마틸다','126.3342731','33.46569094','https://place.map.kakao.com/26463066');
insert into total values('카페더콘테나','126.6789507','33.49807158','https://place.map.kakao.com/665658434');
insert into total values('인그리드','126.4565909','33.50246386','https://place.map.kakao.com/769399654');
insert into total values('꽃이피다앤블라썸','126.5546664','33.24292217','https://place.map.kakao.com/1028406499');
insert into total values('레이지펌프','126.3095451','33.46625527','https://place.map.kakao.com/88307711');
insert into total values('제주바솔트','126.5392326','33.5040906','https://place.map.kakao.com/1613900075');
insert into total values('라토커피','126.5281543','33.49869868','https://place.map.kakao.com/2020231452');
insert into total values('섬타르','126.4782068','33.48757538','https://place.map.kakao.com/1207320787');
insert into total values('지금이순간','126.3109935','33.46041705','https://place.map.kakao.com/2058969392');
insert into total values('북촌에가면','126.6925866','33.54801518','https://place.map.kakao.com/2080549056');
insert into total values('썬셋클리프','126.3107009','33.46180082','https://place.map.kakao.com/611667902');
insert into total values('쪼끌락','126.7552079','33.55777423','https://place.map.kakao.com/26532312');
insert into total values('제레미','126.3185633','33.46463129','https://place.map.kakao.com/1170785054');
insert into total values('블랑로쉐','126.9579027','33.51567651','https://place.map.kakao.com/26862756');
insert into total values('구좌상회작업실','126.6987276','33.4855447','https://place.map.kakao.com/26884074');
insert into total values('허니문하우스','126.5789042','33.24474903','https://place.map.kakao.com/775734317');
insert into total values('커피파인더','126.5286797','33.49857879','https://place.map.kakao.com/1505002027');
insert into total values('커피스케치','126.3132898','33.23336843','https://place.map.kakao.com/1688963481');
insert into total values('마마롱','126.4391774','33.45215188','https://place.map.kakao.com/27469103');
insert into total values('벙커하우스','126.5192243','33.24046167','https://place.map.kakao.com/670044535');
insert into total values('마음에온','126.5260044','33.51450929','https://place.map.kakao.com/522395014');
insert into total values('와토커피','126.2565438','33.22547128','https://place.map.kakao.com/1028238972');
insert into total values('니모메','126.4309431','33.49372672','https://place.map.kakao.com/1146640630');
insert into total values('당당','126.3708824','33.47444574','https://place.map.kakao.com/634174711');
insert into total values('쉼표','126.2419544','33.39525502','https://place.map.kakao.com/20465427');
insert into total values('미스틱3도','126.487368','33.44999341','https://place.map.kakao.com/263044374');
insert into total values('풀베개','126.303106','33.28534552','https://place.map.kakao.com/1166960013');
insert into total values('카페바나나 중문점','126.4171221','33.25802992','https://place.map.kakao.com/2095612103');
insert into total values('카페한라산','126.8630091','33.52478095','https://place.map.kakao.com/898585862');
insert into total values('오늘은녹차한잔','126.791736','33.38138152','https://place.map.kakao.com/24598037');
insert into total values('비브레이브 혁신도시점','126.518175','33.2549285','https://place.map.kakao.com/767876049');
insert into total values('브와두스 베이커리카페 연동점','126.4903092','33.47882565','https://place.map.kakao.com/25771881');
insert into total values('우무 제주시점','126.5233815','33.50982125','https://place.map.kakao.com/1043872917');
insert into total values('호랑호랑','126.921544','33.45003053','https://place.map.kakao.com/1133384427');
insert into total values('본카페 애월','126.3320794','33.46778758','https://place.map.kakao.com/823443118');
insert into total values('미쿠니','126.5896258','33.52907774','https://place.map.kakao.com/864251848');
insert into total values('모노클제주','126.684537','33.27289826','https://place.map.kakao.com/337455511');
insert into total values('트라인커피','126.6332213','33.49395506','https://place.map.kakao.com/1363724318');
insert into total values('플랏포커피','126.4828374','33.48698214','https://place.map.kakao.com/2042761032');
insert into total values('카페세렌디','126.4108713','33.24993006','https://place.map.kakao.com/367412374');
insert into total values('머문','126.7957678','33.55556963','https://place.map.kakao.com/1589936933');
insert into total values('카페태희','126.3043939','33.44936282','https://place.map.kakao.com/25050406');
insert into total values('두갓','126.4493016','33.46460556','https://place.map.kakao.com/2041432492');
insert into total values('모뉴에트','126.9023303','33.49155763','https://place.map.kakao.com/1307726606');
insert into total values('청춘부부','126.2791065','33.26592157','https://place.map.kakao.com/1663041096');
insert into total values('골목카페옥수','126.3798852','33.43995071','https://place.map.kakao.com/481425144');
insert into total values('그러므로 파트2','126.4858838','33.46842888','https://place.map.kakao.com/1569763514');
insert into total values('카페브리프','126.4156746','33.45834308','https://place.map.kakao.com/276957303');
insert into total values('이너프','126.4189799','33.4560214','https://place.map.kakao.com/679736866');
insert into total values('카페 동백','126.7146754','33.50887488','https://place.map.kakao.com/1208953462');
insert into total values('그초록','126.8065481','33.55645242','https://place.map.kakao.com/1782977249');
insert into total values('아뜰리에안','126.5059955','33.23150177','https://place.map.kakao.com/1250970494');
insert into total values('스테이위드커피','126.4557314','33.45825406','https://place.map.kakao.com/15264554');
insert into total values('카페콜라','126.2919209','33.44331764','https://place.map.kakao.com/27237081');
insert into total values('스타벅스 제주용담DT점','126.4845104','33.51240039','https://place.map.kakao.com/26102947');
insert into total values('카페공작소','126.8598778','33.52464188','https://place.map.kakao.com/18771353');
insert into total values('더리트리브','126.3385636','33.24792962','https://place.map.kakao.com/791617298');
insert into total values('코코티에','126.8446348','33.32645728','https://place.map.kakao.com/1562657538');
insert into total values('랜딩커피','126.9189046','33.43550906','https://place.map.kakao.com/1335585931');
insert into total values('달빛제주','126.3944427','33.4837899','https://place.map.kakao.com/1358103055');
insert into total values('카페바나나 함덕점','126.6631005','33.54381711','https://place.map.kakao.com/573133854');
insert into total values('요요무문','126.8367429','33.53816086','https://place.map.kakao.com/26885600');
insert into total values('에스프레소라운지','126.472801','33.48065362','https://place.map.kakao.com/437916891');
insert into total values('프로젝트064다방','126.4885408','33.48878187','https://place.map.kakao.com/26784906');
insert into total values('수마','126.9338745','33.46099324','https://place.map.kakao.com/83691382');
insert into total values('모래비','126.7960161','33.55551242','https://place.map.kakao.com/18325298');
insert into total values('우유부단','126.328055','33.34761151','https://place.map.kakao.com/825851613');
insert into total values('스타벅스 제주애월DT점','126.3487527','33.47269873','https://place.map.kakao.com/1693150085');
insert into total values('5L2F','126.6333104','33.49405156','https://place.map.kakao.com/615740956');
insert into total values('망고홀릭 제주본점','126.4919587','33.49072177','https://place.map.kakao.com/26453267');
insert into total values('앨리스','126.5295643','33.49756656','https://place.map.kakao.com/15866494');
insert into total values('온오프','126.961348','33.51292256','https://place.map.kakao.com/1630713791');
insert into total values('슬랩','126.2416298','33.39483568','https://place.map.kakao.com/555396252');
insert into total values('어린왕자감귤밭','126.2815262','33.2535011','https://place.map.kakao.com/1260410910');
insert into total values('카페노티드 제주애월','126.3097358','33.46327517','https://place.map.kakao.com/1775255132');
insert into total values('블루보틀 제주 카페','126.7508535','33.43327744','https://place.map.kakao.com/1501896613');
insert into total values('카페글렌코','126.7334322','33.43340891','https://place.map.kakao.com/213125558');
insert into total values('서귀피안','126.5288366','33.24842132','https://place.map.kakao.com/834666065');
insert into total values('텐저린카페','126.5087098','33.23628121','https://place.map.kakao.com/809248605');
insert into total values('스타벅스 제주중문점','126.4124796','33.25105243','https://place.map.kakao.com/17884787');
insert into total values('빠빠라기 신제주점','126.4902894','33.48801146','https://place.map.kakao.com/15639202');
insert into total values('와랑와랑','126.6765526','33.27228533','https://place.map.kakao.com/18815393');
insert into total values('그계절','126.8185106','33.53182156','https://place.map.kakao.com/59334207');
insert into total values('스타벅스 제주성산DT점','126.9206935','33.44970862','https://place.map.kakao.com/414395112');
insert into total values('사계생활','126.2963138','33.23153224','https://place.map.kakao.com/1852395758');
insert into total values('카페리','126.839672','33.53397908','https://place.map.kakao.com/1886872931');
insert into total values('말로','126.672114','33.42747685','https://place.map.kakao.com/922717571');
insert into total values('스타벅스 제주함덕점','126.6686225','33.54249241','https://place.map.kakao.com/454445122');
insert into total values('어제보다오늘','126.4569724','33.50285715','https://place.map.kakao.com/193625605');
insert into total values('다소니','126.5176673','33.49068365','https://place.map.kakao.com/10267331');
insert into total values('서홍정원','126.5544141','33.2525881','https://place.map.kakao.com/1229685652');
insert into total values('온더스톤브런치카페','126.9179998','33.47020298','https://place.map.kakao.com/27542243');
insert into total values('르토아베이스먼트','126.8442755','33.53299004','https://place.map.kakao.com/908753935');
insert into total values('망고레이 섭지코지점','126.920514','33.43634639','https://place.map.kakao.com/26301545');
insert into total values('오드씽','126.5268844','33.46202021','https://place.map.kakao.com/888730662');
insert into total values('모모제이','126.5487332','33.47612898','https://place.map.kakao.com/132566301');
insert into total values('1158족욕카페','126.3365101','33.46709872','https://place.map.kakao.com/1787101427');
insert into total values('비마이게스트','126.2454938','33.39797282','https://place.map.kakao.com/587340308');
insert into total values('마노커피하우스','126.4275374','33.25688562','https://place.map.kakao.com/1824227168');
insert into total values('카페진정성 종점','126.4628732','33.50241515','https://place.map.kakao.com/1338637391');
insert into total values('카페그라나다','126.4640576','33.49945896','https://place.map.kakao.com/1440596180');
insert into total values('컴플리트커피 연동점','126.4913001','33.47824414','https://place.map.kakao.com/25922832');
insert into total values('오늘의바다','126.5184965','33.24166004','https://place.map.kakao.com/1131993961');
insert into total values('스타벅스 성산일출봉점','126.9354994','33.46286426','https://place.map.kakao.com/18143017');
insert into total values('빽다방 베이커리 제주사수점','126.4766247','33.50928254','https://place.map.kakao.com/1808915729');
insert into total values('모립','126.3097207','33.46300229','https://place.map.kakao.com/842886196');
insert into total values('스타벅스 서귀포DT','126.5067221','33.24952057','https://place.map.kakao.com/27075901');
insert into total values('스타벅스 제주중문DT점','126.4158537','33.25506845','https://place.map.kakao.com/26900356');
insert into total values('그리울땐제주','126.7706264','33.30097922','https://place.map.kakao.com/258584774');
insert into total values('노고로시','126.2773489','33.42363862','https://place.map.kakao.com/317102094');
insert into total values('바람벽에흰당나귀','126.7075939','33.55385288','https://place.map.kakao.com/25746672');
insert into total values('돌카롱 사려니숲길본점','126.657143','33.42594086','https://place.map.kakao.com/816844811');
insert into total values('인스밀','126.2292254','33.2384714','https://place.map.kakao.com/670941856');
insert into total values('73st','126.4551344','33.45700548','https://place.map.kakao.com/1500989680');
insert into total values('스물다섯','126.4807951','33.48897995','https://place.map.kakao.com/1571910152');
insert into total values('모카다방','126.7613874','33.29217343','https://place.map.kakao.com/27491731');
insert into total values('ABC베이커리','126.5233795','33.51694182','https://place.map.kakao.com/2086134863');
insert into total values('엘파소 Elpaso','126.325924','33.24539151','https://place.map.kakao.com/317558169');
insert into total values('카페도두','126.4816274','33.51017499','https://place.map.kakao.com/1337328227');
insert into total values('어니스트밀크 성산점','126.9298667','33.46059371','https://place.map.kakao.com/1984207097');
insert into total values('풍림다방 송당점','126.7857064','33.47186765','https://place.map.kakao.com/812803632');
insert into total values('스타벅스 제주노형점','126.4818554','33.48782521','https://place.map.kakao.com/26801319');
insert into total values('영국찻집','126.3141184','33.41724266','https://place.map.kakao.com/310705633');
insert into total values('윈드스톤','126.4360748','33.46045336','https://place.map.kakao.com/693016371');
insert into total values('카페주비','126.4607631','33.50004917','https://place.map.kakao.com/1043811001');
insert into total values('시루애월','126.391818','33.44271404','https://place.map.kakao.com/819891458');
insert into total values('씨사이드 애월하귀점','126.4076953','33.48499196','https://place.map.kakao.com/798656427');
insert into total values('제주설심당 본점','126.4928963','33.51943952','https://place.map.kakao.com/24812797');
insert into total values('Pickus 피커스','126.5287704','33.4738817','https://place.map.kakao.com/843686446');
insert into total values('신산리마을카페','126.8768206','33.37661886','https://place.map.kakao.com/26944414');
insert into total values('카페블루하우스 올레시장점','126.5610124','33.25117243','https://place.map.kakao.com/639436403');
insert into total values('호텔샌드','126.2404413','33.39384281','https://place.map.kakao.com/1500112810');
insert into total values('달자카페','126.3796433','33.48364462','https://place.map.kakao.com/26303350');
insert into total values('미엘드세화','126.8618359','33.52451453','https://place.map.kakao.com/25161778');
insert into total values('스타벅스 제주협재점','126.2403271','33.39384165','https://place.map.kakao.com/1617472209');
insert into total values('스타벅스 제주칠성점','126.5252442','33.51334995','https://place.map.kakao.com/26643820');
insert into total values('에이바우트커피 한라대점','126.4755676','33.47815234','https://place.map.kakao.com/717587648');
insert into total values('카페유주','126.2572406','33.4054854','https://place.map.kakao.com/986232032');
insert into total values('누옥','126.5287277','33.50825445','https://place.map.kakao.com/2052698459');
insert into total values('인카페온더비치','126.8280439','33.54519641','https://place.map.kakao.com/599191002');
insert into total values('풍미독서','126.8590057','33.51384682','https://place.map.kakao.com/1754902304');
insert into total values('우호적무관심','126.2672101','33.33772928','https://place.map.kakao.com/615161662');
insert into total values('스타벅스 제주송악산점','126.2899733','33.20677718','https://place.map.kakao.com/23900952');
insert into total values('듀포레','126.5000929','33.51852593','https://place.map.kakao.com/1914659693');
insert into total values('조아찌커피','126.4505759','33.49681114','https://place.map.kakao.com/25532537');
insert into total values('모앙','126.5473301','33.47593214','https://place.map.kakao.com/723636395');
insert into total values('선흘','126.6992363','33.48589297','https://place.map.kakao.com/1832440912');
insert into total values('카페숨도','126.5370605','33.25062623','https://place.map.kakao.com/1263496734');
insert into total values('볕이드는곳벧디','126.4880634','33.47134517','https://place.map.kakao.com/64602009');
insert into total values('스타벅스 제주시청점','126.5295298','33.5004783','https://place.map.kakao.com/1551305286');
insert into total values('디피159','126.4378299','33.23947075','https://place.map.kakao.com/662897569');
insert into total values('동박낭','126.6770019','33.27604605','https://place.map.kakao.com/2061851154');
insert into total values('순아','126.5227006','33.51304021','https://place.map.kakao.com/440194716');
insert into total values('그레이그로브','126.2998184','33.22584113','https://place.map.kakao.com/528303189');
insert into total values('속솜','126.8798438','33.52859709','https://place.map.kakao.com/1599485415');
insert into total values('사일리커피','126.2762684','33.20008273','https://place.map.kakao.com/1148912647');
insert into total values('모알보알 제주','126.7279518','33.55956443','https://place.map.kakao.com/923804248');
insert into total values('바라나시책골목','126.5152118','33.51634503','https://place.map.kakao.com/484703392');
insert into total values('알마커피제작소','126.6947944','33.5502325','https://place.map.kakao.com/1491888881');
insert into total values('동명정류장','126.2662354','33.39714136','https://place.map.kakao.com/1315063856');
insert into total values('스타벅스 제주외도DT점','126.427073','33.49233139','https://place.map.kakao.com/1443975060');
insert into total values('3인칭관찰자시점','126.1811909','33.34973705','https://place.map.kakao.com/1947663934');
insert into total values('플레이스엉물','126.9006568','33.48963183','https://place.map.kakao.com/821064310');
insert into total values('커피99','126.484613','33.46972508','https://place.map.kakao.com/26392726');
insert into total values('바다위에코끼리','126.2429456','33.39786703','https://place.map.kakao.com/2083166873');
insert into total values('카페바르941','126.9163237','33.43486224','https://place.map.kakao.com/233131508');
insert into total values('이에르바','126.6188895','33.52740438','https://place.map.kakao.com/1161443023');
insert into total values('씨리얼','126.2674082','33.41430934','https://place.map.kakao.com/1665910227');
insert into total values('카페세바','126.7060378','33.51322692','https://place.map.kakao.com/17086100');
insert into total values('그러므로','126.5352278','33.48715758','https://place.map.kakao.com/25147552');
insert into total values('망고홀릭 애월해안도로점','126.341592','33.47053177','https://place.map.kakao.com/221879692');
insert into total values('벨진밧','126.2787718','33.27035003','https://place.map.kakao.com/62025863');
insert into total values('카이로스','126.4001307','33.44926934','https://place.map.kakao.com/1225009208');
insert into total values('바다보는날','126.3780029','33.483933','https://place.map.kakao.com/1099481075');
insert into total values('간세라운지','126.5243169','33.512567','https://place.map.kakao.com/27080594');
insert into total values('모찌롱','126.5219198','33.5120396','https://place.map.kakao.com/1050221982');
insert into total values('다희연','126.7005329','33.47927773','https://place.map.kakao.com/21307939');
insert into total values('무로이','126.3365715','33.30774231','https://place.map.kakao.com/633765117');
insert into total values('까미노','126.3477754','33.45775656','https://place.map.kakao.com/26094495');
insert into total values('볼스카페','126.4424893','33.25341043','https://place.map.kakao.com/403954331');
insert into total values('숑','126.6427649','33.26634195','https://place.map.kakao.com/21524936');
insert into total values('카페희상','126.8382176','33.32994886','https://place.map.kakao.com/1858538846');
insert into total values('너와의첫여행','126.3845411','33.45062506','https://place.map.kakao.com/325110055');
insert into total values('카페곁에','126.713099','33.55349909','https://place.map.kakao.com/1664067453');
insert into total values('인디고인디드','126.3340861','33.46639609','https://place.map.kakao.com/26874310');
insert into total values('스위츠커피바','126.4771322','33.48146626','https://place.map.kakao.com/989498144');
insert into total values('살롱드라방','126.3490229','33.45775228','https://place.map.kakao.com/25665611');
insert into total values('돌카롱 사려니숲길점','126.657143','33.42594086','https://place.map.kakao.com/544218596');
insert into total values('비자블라썸','126.8089666','33.49493138','https://place.map.kakao.com/781815500');
insert into total values('서양차관','126.6159348','33.24212591','https://place.map.kakao.com/1425230111');
insert into total values('바램','126.3525785','33.31115387','https://place.map.kakao.com/1814111982');
insert into total values('하소로커피','126.2178088','33.29546992','https://place.map.kakao.com/2036344906');
insert into total values('카페닐스','126.2559417','33.393396','https://place.map.kakao.com/26885645');
insert into total values('커피주의보','126.537992','33.49276762','https://place.map.kakao.com/71203947');
insert into total values('카페뮤로','126.4878353','33.48737255','https://place.map.kakao.com/1452036521');
insert into total values('안도르','126.7710372','33.45529983','https://place.map.kakao.com/1756541636');
insert into total values('에이바우트커피 신라신성점','126.486719','33.48577156','https://place.map.kakao.com/1800067564');
insert into total values('오버더윈도우','126.5613205','33.24519481','https://place.map.kakao.com/1191527008');
insert into total values('카페오드리','126.297324','33.35694552','https://place.map.kakao.com/525040777');
insert into total values('에이바우트커피 칠성점','126.5257121','33.51620926','https://place.map.kakao.com/1602152285');
insert into total values('카페코지','126.9292659','33.4682193','https://place.map.kakao.com/17880473');
insert into total values('노바운더리 제주','126.7831906','33.40180346','https://place.map.kakao.com/1873509504');
insert into total values('카페두가시','126.3667163','33.23546428','https://place.map.kakao.com/1456765484');
insert into total values('회춘 애월점','126.3907988','33.48911237','https://place.map.kakao.com/1268475464');
insert into total values('먹쿠슬낭여행자카페','126.5070014','33.49805069','https://place.map.kakao.com/22400644');
insert into total values('말리가','126.2489977','33.38714036','https://place.map.kakao.com/1220270738');
insert into total values('매기의추억','126.2776617','33.44088474','https://place.map.kakao.com/24266478');
insert into total values('카페살레','126.9574295','33.51300693','https://place.map.kakao.com/811454849');
insert into total values('카페더라이트','126.9359926','33.46563208','https://place.map.kakao.com/680958794');
insert into total values('시인의집','126.6345519','33.53600297','https://place.map.kakao.com/14974263');
insert into total values('카카듀','126.5417837','33.49130649','https://place.map.kakao.com/16026907');
insert into total values('픽스커피 본점','126.5439392','33.49142804','https://place.map.kakao.com/310452204');
insert into total values('블루모모','126.5322726','33.49767225','https://place.map.kakao.com/1957800805');
insert into total values('스타벅스 제주노형공원점','126.4824841','33.48170423','https://place.map.kakao.com/164638813');
insert into total values('카페유디에이','126.528528','33.24102743','https://place.map.kakao.com/1830094932');
insert into total values('미깡창고','126.4453249','33.46021439','https://place.map.kakao.com/314991516');
insert into total values('봉꾸라주','126.5057779','33.25428215','https://place.map.kakao.com/1309419159');
insert into total values('델문도로스터스','126.5263333','33.49180954','https://place.map.kakao.com/1115019463');
insert into total values('리치망고 애월본점','126.3401777','33.46855015','https://place.map.kakao.com/20290778');
insert into total values('다랑쉬','126.5094531','33.50891463','https://place.map.kakao.com/691894331');
insert into total values('스타벅스 제주신화월드R점','126.3163567','33.30497983','https://place.map.kakao.com/258547215');
insert into total values('카페2472','126.41644','33.25588864','https://place.map.kakao.com/922031961');
insert into total values('하빌리스 커피로스터스','126.5171701','33.50456015','https://place.map.kakao.com/27541357');
insert into total values('투썸플레이스 제주용두암점','126.5039076','33.51661991','https://place.map.kakao.com/770545912');
insert into total values('귤꽃다락','126.522535','33.2464158','https://place.map.kakao.com/1437167844');
insert into total values('수카사','126.8081573','33.55408366','https://place.map.kakao.com/1444298172');
insert into total values('여섯번의보름','126.5304549','33.25691444','https://place.map.kakao.com/1675972774');
insert into total values('쉬리니케이크','126.328198','33.43849222','https://place.map.kakao.com/1545999578');
insert into total values('어니스트밀크 본점','126.8718813','33.45041007','https://place.map.kakao.com/718346639');
insert into total values('리틀포레스트','126.4592827','33.24480563','https://place.map.kakao.com/1192457959');
insert into total values('카페동경앤책방','126.4048499','33.48134462','https://place.map.kakao.com/315193014');
insert into total values('60빈스','126.5360488','33.24193829','https://place.map.kakao.com/21511066');
insert into total values('도바나','126.6664676','33.2755137','https://place.map.kakao.com/1624310743');
insert into total values('섶섬할망카페','126.6022602','33.23791611','https://place.map.kakao.com/25574092');
insert into total values('큐티파이카페','126.3687398','33.47788164','https://place.map.kakao.com/419491158');
insert into total values('고미미','126.517707','33.51534334','https://place.map.kakao.com/1961444877');
insert into total values('에이바우트커피뷰 하귀포구점','126.4083799','33.48645348','https://place.map.kakao.com/1860626172');
insert into total values('카페훤','126.2423839','33.39618147','https://place.map.kakao.com/1632912716');
insert into total values('토템오어','126.2268759','33.33512963','https://place.map.kakao.com/1723598209');
insert into total values('브라보비치','126.9091381','33.47751763','https://place.map.kakao.com/896735066');
insert into total values('도을','126.6572052','33.47356618','https://place.map.kakao.com/861749680');
insert into total values('너븐','126.5739859','33.2452075','https://place.map.kakao.com/918913333');
insert into total values('스타벅스 제주도남DT점','126.5234858','33.48033732','https://place.map.kakao.com/800741220');
insert into total values('블루마운틴 4255','126.8377284','33.37975261','https://place.map.kakao.com/26925526');
insert into total values('아라파파 북촌점','126.6965831','33.55133662','https://place.map.kakao.com/1604463342');
insert into total values('푸르곤','126.3365005','33.43745656','https://place.map.kakao.com/1717813496');
insert into total values('김녕에사는김영훈','126.7463347','33.5542639','https://place.map.kakao.com/1617112127');
insert into total values('서귀피안베이커리','126.9219762','33.43525518','https://place.map.kakao.com/231488419');
insert into total values('카페인사리','126.8258713','33.5390638','https://place.map.kakao.com/1494110869');
insert into total values('소보리당로222','126.3833077','33.26293154','https://place.map.kakao.com/884276488');
insert into total values('노을리카페','126.3728168','33.48006189','https://place.map.kakao.com/1525547515');
insert into total values('블리스찬','126.5033495','33.47336422','https://place.map.kakao.com/2041023368');
insert into total values('동백정원','126.4463723','33.24963504','https://place.map.kakao.com/17376396');
insert into total values('동광','126.5425519','33.48972172','https://place.map.kakao.com/1553305291');
insert into total values('노론존','126.4840837','33.48844327','https://place.map.kakao.com/1151082526');
insert into total values('카페송키','126.5201945','33.5151354','https://place.map.kakao.com/1883569834');
insert into total values('소라의성','126.5770845','33.24535789','https://place.map.kakao.com/26973747');
insert into total values('고요새','126.5867374','33.52551753','https://place.map.kakao.com/1662497255');
insert into total values('과수원피스','126.2270137','33.38549513','https://place.map.kakao.com/1035881278');
insert into total values('그럼외도','126.4340077','33.4943179','https://place.map.kakao.com/1756924125');
insert into total values('이올라니','126.5133983','33.50376463','https://place.map.kakao.com/1315710148');
insert into total values('모헨','126.5168989','33.24108938','https://place.map.kakao.com/1500680130');
insert into total values('에이바우트커피 베라체점','126.5426882','33.49207678','https://place.map.kakao.com/947810595');
insert into total values('브릭커피','126.4713223','33.48254556','https://place.map.kakao.com/949925820');
insert into total values('로즈마린','126.5599983','33.24243278','https://place.map.kakao.com/12815448');
insert into total values('에프터글로우','126.5493873','33.48866048','https://place.map.kakao.com/27517565');
insert into total values('우연히그곳','126.7829719','33.4717357','https://place.map.kakao.com/875047975');
insert into total values('제주몹시','126.4335783','33.49454987','https://place.map.kakao.com/145034193');
insert into total values('하늘꽃카페','126.2819991','33.21316384','https://place.map.kakao.com/1665057137');
insert into total values('간이옥돔역','126.7496826','33.28514574','https://place.map.kakao.com/27184109');
insert into total values('엘리사','126.3899719','33.4853812','https://place.map.kakao.com/1241435799');
insert into total values('헤이브라더','126.2996562','33.22559154','https://place.map.kakao.com/27089912');
insert into total values('안녕토르','126.7034184','33.45998371','https://place.map.kakao.com/1166500601');
insert into total values('스타벅스 제주서해안로DT점','126.5035637','33.51668244','https://place.map.kakao.com/386969795');
insert into total values('투썸플레이스 제주애월한담점','126.3108093','33.46203977','https://place.map.kakao.com/939740355');
insert into total values('미미슈','126.3301103','33.44078424','https://place.map.kakao.com/1668885826');
insert into total values('위더스트래블 아라점','126.5484685','33.4755407','https://place.map.kakao.com/27029887');
insert into total values('오라디오라','126.3081685','33.23505684','https://place.map.kakao.com/1039947224');
insert into total values('롱플레이제주','126.7109424','33.55307048','https://place.map.kakao.com/1185312518');
insert into total values('카페어떤오후','126.345977','33.45076021','https://place.map.kakao.com/322555256');
insert into total values('토끼문','126.7954824','33.55589153','https://place.map.kakao.com/927947271');
insert into total values('스타벅스 제주삼화DT점','126.5802411','33.51174228','https://place.map.kakao.com/207217035');
insert into total values('쉬어갓','126.8822686','33.38609198','https://place.map.kakao.com/45616760');
insert into total values('비양놀','126.2635068','33.42897922','https://place.map.kakao.com/151449756');
insert into total values('에이바우트스타디움','126.5643131','33.50496351','https://place.map.kakao.com/175162706');
insert into total values('타요키즈카페 제주용담점','126.5144937','33.50660878','https://place.map.kakao.com/2058522387');
insert into total values('카페빠네띠에','126.5460689','33.49464851','https://place.map.kakao.com/19632853');
insert into total values('무상찻집','126.5143905','33.50099915','https://place.map.kakao.com/1575289135');
insert into total values('하라케케','126.527975','33.24213467','https://place.map.kakao.com/1812213124');
insert into total values('안녕육지사람','126.9571648','33.51508927','https://place.map.kakao.com/18742934');
insert into total values('브릭스제주','126.7429879','33.55465268','https://place.map.kakao.com/26900601');
insert into total values('카페아오오','126.879959','33.37908909','https://place.map.kakao.com/1441787320');
insert into total values('색달로망스','126.4110805','33.26075737','https://place.map.kakao.com/435677061');
insert into total values('소이재','126.4786144','33.48913002','https://place.map.kakao.com/807371912');
insert into total values('피플카페','126.6138248','33.53795785','https://place.map.kakao.com/1915394502');
insert into total values('카페미와','126.8570967','33.5231979','https://place.map.kakao.com/1064788897');
insert into total values('꽃향유','126.3476116','33.45707176','https://place.map.kakao.com/2069872093');
insert into total values('제이아일랜드카페','126.8797266','33.37879596','https://place.map.kakao.com/2139926867');
insert into total values('카페월령','126.21677','33.3786965','https://place.map.kakao.com/18722453');
insert into total values('잔디공장','126.8733183','33.37751113','https://place.map.kakao.com/284978');
insert into total values('카페청굴물','126.7512929','33.55798737','https://place.map.kakao.com/325780473');
insert into total values('오늘도화창','126.7949673','33.55515587','https://place.map.kakao.com/1138154447');
insert into total values('너는파라다이스길리','126.7937059','33.55669206','https://place.map.kakao.com/80778995');
insert into total values('카페마니','126.8372794','33.53728886','https://place.map.kakao.com/27167180');
insert into total values('네이처캔버스','126.6307632','33.28307109','https://place.map.kakao.com/713222734');
insert into total values('올디벗구디','126.4735307','33.2530584','https://place.map.kakao.com/148780844');
insert into total values('카페갤럭시아','126.3103566','33.23381509','https://place.map.kakao.com/171790450');
insert into total values('카페책자국','126.9076907','33.49625546','https://place.map.kakao.com/1221602642');
insert into total values('걸어가는늑대들','126.6724598','33.5426083','https://place.map.kakao.com/1605214000');
insert into total values('다린','126.5138408','33.23652043','https://place.map.kakao.com/1228219754');
insert into total values('알맞은시간','126.7690987','33.3065083','https://place.map.kakao.com/552481804');
insert into total values('단정한까페','126.5292021','33.49680837','https://place.map.kakao.com/150782347');
insert into total values('차귀놀','126.1668596','33.32226228','https://place.map.kakao.com/1901985824');
insert into total values('하우스레서피 당근케이크','126.2954337','33.44392903','https://place.map.kakao.com/11539852');
insert into total values('리듬앤브루스','126.519851','33.51379668','https://place.map.kakao.com/427669200');
insert into total values('트로피컬하이드어웨이','126.2912766','33.20923858','https://place.map.kakao.com/1055250555');
insert into total values('스타벅스 제주에듀시티점','126.2842901','33.29182128','https://place.map.kakao.com/1013067175');
insert into total values('에오마르','126.5865662','33.52573507','https://place.map.kakao.com/1843119686');
insert into total values('카페파람','126.1712374','33.34180468','https://place.map.kakao.com/20199015');
insert into total values('이스틀리','126.9084038','33.45608152','https://place.map.kakao.com/2043082568');
insert into total values('에이바우트커피 삼무공원점','126.4898986','33.49038265','https://place.map.kakao.com/1655600759');
insert into total values('빌라드아토','126.5644949','33.24496726','https://place.map.kakao.com/242368968');
insert into total values('망고홀릭','126.5132424','33.23425855','https://place.map.kakao.com/26453253');
insert into total values('아일렛','126.5358003','33.48909891','https://place.map.kakao.com/27335344');
insert into total values('롱리브','126.541526','33.47658755','https://place.map.kakao.com/283241962');
insert into total values('코데인커피로스터스','126.2961673','33.2351791','https://place.map.kakao.com/655909706');
insert into total values('에이바우트커피 시청점','126.5308475','33.49876939','https://place.map.kakao.com/284718590');
insert into total values('토끼썸','126.8985994','33.52175365','https://place.map.kakao.com/851584544');
insert into total values('카페원웨이','126.1930935','33.36242735','https://place.map.kakao.com/378533601');
insert into total values('배롱정원','126.2414714','33.3930495','https://place.map.kakao.com/1938789532');
insert into total values('솔트스톤','126.5425161','33.50037533','https://place.map.kakao.com/202549752');
insert into total values('커피맛이멜로','126.3662717','33.31229424','https://place.map.kakao.com/13312181');
insert into total values('돌미롱','126.5439884','33.47458627','https://place.map.kakao.com/24710611');
insert into total values('페어리제주','126.8641361','33.52482959','https://place.map.kakao.com/161861462');
insert into total values('블로비노형','126.4787952','33.46689939','https://place.map.kakao.com/48895473');
insert into total values('밀팟제주','126.5298039','33.48417165','https://place.map.kakao.com/895835518');
insert into total values('에이바우트커피 삼화점','126.572667','33.5154221','https://place.map.kakao.com/878012600');
insert into total values('벌툰 제주한라대점','126.4803946','33.47614246','https://place.map.kakao.com/1561892662');
insert into total values('꼬라지오','126.5507307','33.25252622','https://place.map.kakao.com/1679756496');
insert into total values('카페갤러리','126.6754953','33.42210803','https://place.map.kakao.com/1983699002');
insert into total values('카페 제주동네','126.898611','33.49331197','https://place.map.kakao.com/22960776');
insert into total values('거인의정원','126.5352469','33.47184317','https://place.map.kakao.com/405890910');
insert into total values('꼬스뗀뇨','126.9050577','33.50967056','https://place.map.kakao.com/1937247194');
insert into total values('플레이커피랩','126.5588093','33.2505898','https://place.map.kakao.com/26885582');
insert into total values('스테이솔티','126.7981598','33.55451109','https://place.map.kakao.com/2065132848');
insert into total values('카페폴린','126.5736422','33.24611925','https://place.map.kakao.com/969382627');
insert into total values('헬로남생이','126.6140276','33.53358283','https://place.map.kakao.com/475813760');
insert into total values('효은양갱','126.3145144','33.25192702','https://place.map.kakao.com/100535814');
insert into total values('카페소금','126.375966','33.48246925','https://place.map.kakao.com/1450044291');
insert into total values('우드스탁','126.7966168','33.55532418','https://place.map.kakao.com/1502956536');
insert into total values('카페루핀','126.2913359','33.21038677','https://place.map.kakao.com/1558161696');
insert into total values('카페오길','126.8422584','33.53189702','https://place.map.kakao.com/398553794');
insert into total values('망고레이 천지연폭포점','126.559685','33.24337295','https://place.map.kakao.com/1307401167');
insert into total values('애월후식','126.3301767','33.43899117','https://place.map.kakao.com/2138824476');
insert into total values('오지힐 제주점','126.1933743','33.36274146','https://place.map.kakao.com/717162944');
insert into total values('컴컴제주','126.2510508','33.40139295','https://place.map.kakao.com/233743673');
insert into total values('트라이브','126.3110209','33.46028086','https://place.map.kakao.com/442131150');
insert into total values('초이당','126.7312539','33.28058869','https://place.map.kakao.com/1872624931');
insert into total values('카페쌀쌀','126.3641827','33.47514437','https://place.map.kakao.com/952591642');
insert into total values('리유니온','126.5303634','33.49752998','https://place.map.kakao.com/996009126');
insert into total values('카페멘도롱','126.2513261','33.2195487','https://place.map.kakao.com/26491535');
insert into total values('점점','126.6152379','33.53701535','https://place.map.kakao.com/145331867');
insert into total values('로스트&헤븐','126.4509975','33.49677178','https://place.map.kakao.com/1817863662');
insert into total values('유스커피','126.5406551','33.48431927','https://place.map.kakao.com/26915477');
insert into total values('미리로','126.4483834','33.49757604','https://place.map.kakao.com/85293537');
insert into total values('우연못','126.487625','33.46675987','https://place.map.kakao.com/1773337836');
insert into total values('메이비','126.5642324','33.24498332','https://place.map.kakao.com/12591043');
insert into total values('술의식물원','126.7837792','33.47188016','https://place.map.kakao.com/657512517');
insert into total values('카페차롱','126.354415','33.25971036','https://place.map.kakao.com/2039811828');
insert into total values('슬로보트 아뜰리에','126.4143807','33.4901093','https://place.map.kakao.com/120215718');
insert into total values('팡송','126.6596657','33.27490635','https://place.map.kakao.com/1256200573');
insert into total values('카페 뵤뵤','126.2630843','33.39253629','https://place.map.kakao.com/837901136');
insert into total values('초가헌','126.801271','33.39033218','https://place.map.kakao.com/2117340011');
insert into total values('픽스커피 화북공단점','126.5720528','33.51464293','https://place.map.kakao.com/1609707143');
insert into total values('왓섬','126.5220887','33.46631502','https://place.map.kakao.com/1076949402');
insert into total values('그루브','126.2400422','33.39374181','https://place.map.kakao.com/1254546154');
insert into total values('스타벅스 제주일도DT점','126.5408149','33.50728996','https://place.map.kakao.com/1606770927');
insert into total values('보라지붕','126.6701723','33.54078464','https://place.map.kakao.com/572145844');
insert into total values('스타벅스 신제주이마트점','126.4804318','33.48496464','https://place.map.kakao.com/21580659');
insert into total values('88로스터즈','126.5634871','33.52585691','https://place.map.kakao.com/614956036');
insert into total values('바닐라파레트','126.4805909','33.47712716','https://place.map.kakao.com/1788999978');
insert into total values('트라이브 신창점','126.1727893','33.34070528','https://place.map.kakao.com/639029672');
insert into total values('니모스토리','126.7541194','33.55829873','https://place.map.kakao.com/1672417180');
insert into total values('식빵가게','126.5052426','33.50116955','https://place.map.kakao.com/615988591');
insert into total values('그림상회','126.7649128','33.32617913','https://place.map.kakao.com/1550146274');
insert into total values('니나수족욕카페','126.3638656','33.23659725','https://place.map.kakao.com/27445744');
insert into total values('커핏','126.6187908','33.25000783','https://place.map.kakao.com/97770278');
insert into total values('딜레탕트','126.6284236','33.53508964','https://place.map.kakao.com/997116592');
insert into total values('감저','126.2451068','33.22967103','https://place.map.kakao.com/617793541');
insert into total values('주네가네 키친앤카페','126.8067264','33.55630568','https://place.map.kakao.com/26919759');
insert into total values('토토네','126.4106701','33.48938678','https://place.map.kakao.com/1523413414');
insert into total values('오르바','126.6095626','33.24038693','https://place.map.kakao.com/193150969');
insert into total values('탐앤탐스 신제주점','126.4896144','33.48745129','https://place.map.kakao.com/23634725');
insert into total values('제주 함덕 카페 라라떼커피','126.6627402','33.54285079','https://place.map.kakao.com/526568146');
insert into total values('오후다섯시 두가지착각 조차도','126.6485472','33.55215534','https://place.map.kakao.com/789979470');
insert into total values('히아담','126.4864467','33.47611887','https://place.map.kakao.com/1527163571');
insert into total values('공생','126.5432786','33.50824592','https://place.map.kakao.com/1243067692');
insert into total values('카페 세러데이아일랜드','126.7145877','33.28126353','https://place.map.kakao.com/425388112');
insert into total values('윤재커피','126.5241044','33.51184154','https://place.map.kakao.com/371491242');
insert into total values('인터포레스트','126.7723706','33.4572406','https://place.map.kakao.com/1228240223');
insert into total values('페이보리오리','126.6172867','33.2569298','https://place.map.kakao.com/638371572');
insert into total values('그리트커피','126.5492474','33.47517572','https://place.map.kakao.com/582507428');
insert into total values('카페팀블로우','126.3108271','33.46108051','https://place.map.kakao.com/1688963064');
insert into total values('종달리746','126.9025218','33.49188551','https://place.map.kakao.com/679438504');
insert into total values('유티피커피','126.5424976','33.50236165','https://place.map.kakao.com/1705505338');
insert into total values('스타벅스 서귀포올레점','126.5637211','33.24826376','https://place.map.kakao.com/861385120');
insert into total values('베터플랫','126.5231055','33.51826998','https://place.map.kakao.com/1867906481');
insert into total values('화수목','126.830567','33.54083569','https://place.map.kakao.com/719459055');
insert into total values('제이제이그랑블루','126.309047','33.45664982','https://place.map.kakao.com/704440992');
insert into total values('해거름전망대카페','126.2062196','33.37001297','https://place.map.kakao.com/17350387');
insert into total values('일월선셋비치','126.3092417','33.46292103','https://place.map.kakao.com/647737458');
insert into total values('에이바우트커피 종합청사점','126.5273968','33.49014367','https://place.map.kakao.com/1233024350');
insert into total values('제주소담','126.5074278','33.23148056','https://place.map.kakao.com/2030116210');
insert into total values('스쿠버스카페','126.792246','33.55267239','https://place.map.kakao.com/924582450');
insert into total values('벨라위미','126.6654519','33.27646405','https://place.map.kakao.com/917328798');
insert into total values('디뷰','126.4775114','33.47999693','https://place.map.kakao.com/844788216');
insert into total values('뜻밖의발견','126.5098103','33.25986581','https://place.map.kakao.com/2128776949');
insert into total values('네꼬야티하우스','126.4156147','33.4856703','https://place.map.kakao.com/1566433967');
insert into total values('블라썸1407','126.3475486','33.45685364','https://place.map.kakao.com/1553958207');
insert into total values('폴바셋 제주아라DT점','126.5410047','33.48763868','https://place.map.kakao.com/406312133');
insert into total values('소금빵까페 키친오즈','126.2512066','33.38006919','https://place.map.kakao.com/26792268');
insert into total values('르피크닉','126.3629423','33.23682666','https://place.map.kakao.com/1332741345');
insert into total values('카페단단','126.5216183','33.51258071','https://place.map.kakao.com/165691434');
insert into total values('고도','126.4951126','33.5190697','https://place.map.kakao.com/1092754968');
insert into total values('제대가는길','126.5584336','33.45970005','https://place.map.kakao.com/24873832');
insert into total values('레이지박스','126.3128547','33.23643533','https://place.map.kakao.com/14602309');
insert into total values('제주기와','126.425424','33.45113496','https://place.map.kakao.com/1829041018');
insert into total values('오른(orrrn,오알엔)','126.9157573','33.47180476','https://place.map.kakao.com/2070757323');
insert into total values('나비정원','126.2493247','33.22040463','https://place.map.kakao.com/21607825');
insert into total values('게우지코지인갤러리 커피하우스','126.6185767','33.24379407','https://place.map.kakao.com/1013835521');
insert into total values('아뽀밍고','126.930729','33.45995512','https://place.map.kakao.com/2065881844');
insert into total values('슈가탱크','126.9590434','33.49416434','https://place.map.kakao.com/1009948858');
insert into total values('어글리딜리셔스','126.53592','33.48898367','https://place.map.kakao.com/1383951398');
insert into total values('카페 가드니아','126.828656','33.31805816','https://place.map.kakao.com/1377309150');
insert into total values('몽그레','126.792716','33.55959405','https://place.map.kakao.com/1598780569');
insert into total values('커피동굴','126.5391793','33.51463807','https://place.map.kakao.com/259690308');
insert into total values('카페지니','126.640634','33.26486156','https://place.map.kakao.com/26320023');
insert into total values('도리화과','126.5095622','33.4690814','https://place.map.kakao.com/1766276489');
insert into total values('제주901','126.4863451','33.4529501','https://place.map.kakao.com/27456049');
insert into total values('941헤르츠','126.4850525','33.48533176','https://place.map.kakao.com/24484981');
insert into total values('꽁떼네도르','126.4459512','33.26660254','https://place.map.kakao.com/937776711');
insert into total values('헤이피피','126.1998279','33.36494328','https://place.map.kakao.com/1053673971');
insert into total values('회춘 제주노형점','126.4825736','33.48520438','https://place.map.kakao.com/2124141873');
insert into total values('오가닉제주','126.8573687','33.52299421','https://place.map.kakao.com/624719590');
insert into total values('카페뚜이','126.2445258','33.3988311','https://place.map.kakao.com/791629311');
insert into total values('귤당리','126.1961619','33.36306614','https://place.map.kakao.com/165124400');
insert into total values('핫마마','126.2937314','33.29903507','https://place.map.kakao.com/1361203949');
insert into total values('라라카페','126.4427335','33.45440439','https://place.map.kakao.com/808519483');
insert into total values('바미아일랜드','126.7973377','33.55501936','https://place.map.kakao.com/970602317');
insert into total values('논짓물해수족욕카페','126.3879793','33.23718381','https://place.map.kakao.com/15716106');
insert into total values('카페이시도르','126.3225827','33.34664763','https://place.map.kakao.com/418652493');
insert into total values('해비치불턱','126.8373002','33.312571','https://place.map.kakao.com/17272985');
insert into total values('제주커피집 심심','126.4768944','33.48064013','https://place.map.kakao.com/1283413444');
insert into total values('말로나카페','126.2950514','33.44580685','https://place.map.kakao.com/398384813');
insert into total values('공산명월','126.43317','33.4471815','https://place.map.kakao.com/1685946722');
insert into total values('관심사','126.5245626','33.51124421','https://place.map.kakao.com/1224000506');
insert into total values('다카포카페','126.8369584','33.32454388','https://place.map.kakao.com/1872442419');
insert into total values('성수미술관 제주특별점','126.8865172','33.52689625','https://place.map.kakao.com/125569847');
insert into total values('레드브라운','126.365014','33.23233474','https://place.map.kakao.com/1703109377');
insert into total values('바다바라','126.4129736','33.24589199','https://place.map.kakao.com/139413720');
insert into total values('카페을리','126.3650724','33.28401366','https://place.map.kakao.com/1867774776');
insert into total values('에이바우트커피뷰 강정점','126.4984899','33.23688591','https://place.map.kakao.com/1434835873');
insert into total values('유람위드북스','126.2347696','33.33973893','https://place.map.kakao.com/528690715');
insert into total values('로얄호텔 구내카페','126.4916948','33.48852915','https://place.map.kakao.com/21500283');
insert into total values('컴플렉스','126.5241135','33.51138949','https://place.map.kakao.com/1556209480');
insert into total values('연돈','126.4071709','33.25891018','https://place.map.kakao.com/1890778114');
insert into total values('올래국수 본점','126.4973135','33.49150821','https://place.map.kakao.com/1387964178');
insert into total values('숙성도 노형점','126.4850396','33.48504981','https://place.map.kakao.com/316010726');
insert into total values('고집돌우럭 함덕점','126.6631005','33.54381711','https://place.map.kakao.com/28082185');
insert into total values('제주김만복 본점','126.5085465','33.49695939','https://place.map.kakao.com/1046180098');
insert into total values('우진해장국','126.5200649','33.51147261','https://place.map.kakao.com/11547525');
insert into total values('제주 색달식당','126.3862462','33.24181443','https://place.map.kakao.com/17809788');
insert into total values('고집돌우럭 제주공항점','126.5280582','33.51625818','https://place.map.kakao.com/232056222');
insert into total values('자매국수 본점','126.5170058','33.51682827','https://place.map.kakao.com/21455793');
insert into total values('고집돌우럭 중문점','126.4167028','33.25797666','https://place.map.kakao.com/1580890176');
insert into total values('이춘옥의원조고등어쌈밥','126.4187028','33.4890005','https://place.map.kakao.com/24780480');
insert into total values('제주광해 애월본점','126.3904174','33.48773807','https://place.map.kakao.com/41973236');
insert into total values('오는정김밥','126.5675898','33.24962321','https://place.map.kakao.com/8453998');
insert into total values('늘봄흑돼지','126.4728358','33.47947123','https://place.map.kakao.com/8856076');
insert into total values('중문수두리보말칼국수','126.4250006','33.251566','https://place.map.kakao.com/1148098112');
insert into total values('맛나식당','126.9160168','33.44854228','https://place.map.kakao.com/8970084');
insert into total values('착한집','126.5070118','33.49996733','https://place.map.kakao.com/1762863151');
insert into total values('한림칼국수','126.2614971','33.41555595','https://place.map.kakao.com/22893211');
insert into total values('바다를본돼지 제주협재판포본점','126.1979224','33.36564149','https://place.map.kakao.com/18507401');
insert into total values('노라바','126.3763076','33.48279369','https://place.map.kakao.com/26352466');
insert into total values('춘심이네 본점','126.3702605','33.26430979','https://place.map.kakao.com/19316749');
insert into total values('돈사돈본관','126.4640243','33.47886576','https://place.map.kakao.com/26799620');
insert into total values('곰막식당','126.7204144','33.55674828','https://place.map.kakao.com/18421685');
insert into total values('애월하미','126.3091431','33.46388393','https://place.map.kakao.com/904105639');
insert into total values('은희네해장국 본점','126.5407453','33.50853749','https://place.map.kakao.com/21499653');
insert into total values('칠돈가','126.5107152','33.50232164','https://place.map.kakao.com/249906601');
insert into total values('미영이네식당','126.2498112','33.21774651','https://place.map.kakao.com/9006988');
insert into total values('가시아방국수','126.9180776','33.4386283','https://place.map.kakao.com/22895321');
insert into total values('제주시새우리 제주점','126.5207382','33.5146109','https://place.map.kakao.com/2146989435');
insert into total values('제주김만복 동문시장점','126.5178335','33.51528806','https://place.map.kakao.com/942388111');
insert into total values('명진전복','126.8498196','33.53239576','https://place.map.kakao.com/20031551');
insert into total values('일통이반','126.5220813','33.5170702','https://place.map.kakao.com/1146457759');
insert into total values('제주김만복 애월점','126.3389817','33.46760774','https://place.map.kakao.com/1781134153');
insert into total values('제주오성식당','126.414669','33.25570634','https://place.map.kakao.com/10627937');
insert into total values('당케올레국수','126.8433381','33.32529375','https://place.map.kakao.com/25589899');
insert into total values('해녀김밥 함덕 본점','126.6651813','33.5425516','https://place.map.kakao.com/1412534993');
insert into total values('수우동','126.2423391','33.39658353','https://place.map.kakao.com/24910644');
insert into total values('삼대국수회관 본점','126.530061','33.506903','https://place.map.kakao.com/1027828348');
insert into total values('해왓','126.9171705','33.43852816','https://place.map.kakao.com/382375401');
insert into total values('신설오름','126.5414889','33.50547899','https://place.map.kakao.com/7972099');
insert into total values('도두해녀의집','126.4666278','33.50619277','https://place.map.kakao.com/8894680');
insert into total values('갈치왕 중문점','126.3907582','33.26465112','https://place.map.kakao.com/967549394');
insert into total values('쌍둥이횟집','126.562909','33.24659688','https://place.map.kakao.com/11600257');
insert into total values('해월정','126.9096321','33.49225449','https://place.map.kakao.com/8615207');
insert into total values('고이정 본점','126.3113687','33.45953336','https://place.map.kakao.com/2030021121');
insert into total values('삼무국수','126.4909795','33.49057969','https://place.map.kakao.com/12640510');
insert into total values('장인의집','126.3268439','33.46575397','https://place.map.kakao.com/215455040');
insert into total values('네거리식당','126.5592831','33.24851105','https://place.map.kakao.com/9733194');
insert into total values('국수바다 본점','126.4060001','33.25831588','https://place.map.kakao.com/24839193');
insert into total values('순옥이네명가 본점','126.4649867','33.50562675','https://place.map.kakao.com/1006711661');
insert into total values('바다를본돼지 제주서귀포점','126.5675729','33.24306587','https://place.map.kakao.com/1868841420');
insert into total values('흑돈가 제주본점','126.4734949','33.48005509','https://place.map.kakao.com/1754846295');
insert into total values('상춘재','126.7048514','33.45882373','https://place.map.kakao.com/12397273');
insert into total values('만덕이네','126.8012045','33.39336237','https://place.map.kakao.com/9982608');
insert into total values('무거버거','126.6551781','33.54910718','https://place.map.kakao.com/1356679233');
insert into total values('은희네해장국 노형점','126.4846029','33.48523563','https://place.map.kakao.com/1233978958');
insert into total values('제주김만복김밥 서귀포점','126.5058322','33.23941507','https://place.map.kakao.com/2185536');
insert into total values('큰돈가 중문점','126.4151256','33.25513308','https://place.map.kakao.com/2060352745');
insert into total values('별돈별 정원점','126.1800075','33.30877396','https://place.map.kakao.com/1445399366');
insert into total values('솔지식당','126.4725409','33.49259843','https://place.map.kakao.com/10550164');
insert into total values('모살물','126.4944084','33.49047228','https://place.map.kakao.com/8313670');
insert into total values('도토리키친 본점','126.5185929','33.51537182','https://place.map.kakao.com/158548436');
insert into total values('살아있는해물뚝배기 어마장장','126.5298568','33.51109873','https://place.map.kakao.com/1697090646');
insert into total values('동해미락','126.5682253','33.24366605','https://place.map.kakao.com/12663386');
insert into total values('제주어멍 통갈치','126.4842417','33.51166656','https://place.map.kakao.com/1903594998');
insert into total values('김희선제주몸국','126.498077','33.51855591','https://place.map.kakao.com/17914522');
insert into total values('산도롱맨도롱','126.9101826','33.49688969','https://place.map.kakao.com/27259551');
insert into total values('문개항아리 조천본점','126.6440111','33.55343067','https://place.map.kakao.com/26792593');
insert into total values('용이식당','126.5604777','33.25110525','https://place.map.kakao.com/8526214');
insert into total values('다정이네 올레시장본점','126.5668186','33.24940213','https://place.map.kakao.com/21473782');
insert into total values('제주관덕정분식','126.5243169','33.512567','https://place.map.kakao.com/1951295696');
insert into total values('원담','126.5287852','33.50214894','https://place.map.kakao.com/25406600');
insert into total values('이금돈지','126.4953613','33.48608318','https://place.map.kakao.com/10757125');
insert into total values('옥만이네','126.2634792','33.41637048','https://place.map.kakao.com/285307335');
insert into total values('스시애월','126.3192141','33.46677732','https://place.map.kakao.com/993438455');
insert into total values('국수마당 본점','126.5322066','33.50807423','https://place.map.kakao.com/21295286');
insert into total values('충민정','126.5133447','33.50261877','https://place.map.kakao.com/1728065244');
insert into total values('제주에가면','126.5180093','33.51473694','https://place.map.kakao.com/1929674581');
insert into total values('자리돔횟집','126.574752','33.25552813','https://place.map.kakao.com/9445099');
insert into total values('산방식당','126.2541981','33.22336222','https://place.map.kakao.com/10437289');
insert into total values('국시트멍','126.4813343','33.47936334','https://place.map.kakao.com/20151552');
insert into total values('칠돈가 중문점','126.4144627','33.25746331','https://place.map.kakao.com/1258744113');
insert into total values('진아떡집','126.5283965','33.51236683','https://place.map.kakao.com/10777503');
insert into total values('식당마요네즈 (휴업중)','126.4786634','33.48891063','https://place.map.kakao.com/1525247686');
insert into total values('해녀잠수촌','126.4921544','33.51923272','https://place.map.kakao.com/9648399');
insert into total values('흑돼지BBQ','126.5596561','33.24682487','https://place.map.kakao.com/25448888');
insert into total values('삼보식당','126.559062','33.24754988','https://place.map.kakao.com/11486940');
insert into total values('우니담','126.3484196','33.47250408','https://place.map.kakao.com/517851086');
insert into total values('골막식당','126.5384135','33.50247316','https://place.map.kakao.com/8754112');
insert into total values('다가미','126.5286818','33.49044354','https://place.map.kakao.com/11417273');
insert into total values('치저스','126.7739093','33.46836939','https://place.map.kakao.com/1066733876');
insert into total values('미친부엌','126.5231614','33.51700775','https://place.map.kakao.com/26823759');
insert into total values('훈남횟집','126.6678561','33.54210277','https://place.map.kakao.com/867814713');
insert into total values('데미안','126.2217406','33.3291119','https://place.map.kakao.com/17398890');
insert into total values('복자씨연탄구이','126.9197555','33.46917063','https://place.map.kakao.com/18678487');
insert into total values('제주판타스틱버거','126.778995','33.30848623','https://place.map.kakao.com/251708218');
insert into total values('뽈살집 제주본점','126.5628484','33.25083001','https://place.map.kakao.com/11733078');
insert into total values('고씨네천지국수','126.5607601','33.25174326','https://place.map.kakao.com/1197785972');
insert into total values('천짓골식당','126.5613054','33.24824104','https://place.map.kakao.com/12501703');
insert into total values('유리네','126.4971124','33.48147055','https://place.map.kakao.com/10678894');
insert into total values('신우성흑돼지','126.4111133','33.24962552','https://place.map.kakao.com/2028723819');
insert into total values('바당길','126.2585173','33.40975404','https://place.map.kakao.com/500457527');
insert into total values('국수만찬','126.4954884','33.48713269','https://place.map.kakao.com/8827972');
insert into total values('가시식당','126.7714402','33.35308128','https://place.map.kakao.com/8636832');
insert into total values('연동마라도횟집','126.4894719','33.48680418','https://place.map.kakao.com/27454594');
insert into total values('몬스터살롱','126.3072318','33.44826612','https://place.map.kakao.com/24925007');
insert into total values('원조미풍해장국 본점','126.5228235','33.51120462','https://place.map.kakao.com/11291795');
insert into total values('은희네해장국 함덕점','126.6641603','33.54301587','https://place.map.kakao.com/1482074131');
insert into total values('촌촌해녀촌','126.7101152','33.55371792','https://place.map.kakao.com/25161006');
insert into total values('부두식당','126.2512008','33.21892845','https://place.map.kakao.com/9025009');
insert into total values('바다속고등어쌈밥','126.4067626','33.48427015','https://place.map.kakao.com/20733624');
insert into total values('제주마당','126.4581203','33.49819376','https://place.map.kakao.com/20307028');
insert into total values('살아있는삼성혈해물탕','126.4997045','33.48800332','https://place.map.kakao.com/7919123');
insert into total values('깡촌흑돼지','126.6671342','33.54128736','https://place.map.kakao.com/27525363');
insert into total values('마농치킨 본점','126.5632718','33.24912851','https://place.map.kakao.com/11291724');
insert into total values('산지해장국','126.5285126','33.51636321','https://place.map.kakao.com/25430346');
insert into total values('제주도 해녀세자매','126.2606369','33.41398366','https://place.map.kakao.com/1164617159');
insert into total values('오롯','126.5443477','33.49099601','https://place.map.kakao.com/1735521703');
insert into total values('효퇴국수','126.5196063','33.50153893','https://place.map.kakao.com/17732116');
insert into total values('산방식당 제주점','126.5360089','33.49019185','https://place.map.kakao.com/17358320');
insert into total values('정직한돈 본점','126.3390428','33.46766577','https://place.map.kakao.com/1580336980');
insert into total values('태광식당','126.5187857','33.5126034','https://place.map.kakao.com/24119106');
insert into total values('돈이랑 본점','126.4090948','33.25769927','https://place.map.kakao.com/26586223');
insert into total values('벵디','126.8371776','33.53774036','https://place.map.kakao.com/26412350');
insert into total values('한림칼국수 공항점','126.4676173','33.47895779','https://place.map.kakao.com/357187895');
insert into total values('소금바치순이네','126.9126431','33.50366823','https://place.map.kakao.com/26915572');
insert into total values('화목원','126.4885158','33.47258115','https://place.map.kakao.com/26589689');
insert into total values('난드르바당','126.3710173','33.23463862','https://place.map.kakao.com/26883584');
insert into total values('버드나무집','126.667382','33.54127667','https://place.map.kakao.com/7885885');
insert into total values('은희네해장국 서귀포점','126.5821813','33.26048873','https://place.map.kakao.com/24839178');
insert into total values('남춘식당','126.53751','33.49965785','https://place.map.kakao.com/8244466');
insert into total values('닻','126.3920783','33.48606465','https://place.map.kakao.com/18468300');
insert into total values('은혜전복','126.3101662','33.46298853','https://place.map.kakao.com/380750588');
insert into total values('시골길','126.5006169','33.49647107','https://place.map.kakao.com/12435417');
insert into total values('올레왕갈치','126.56275','33.24854732','https://place.map.kakao.com/1056381412');
insert into total values('순천미향','126.3124833','33.23567083','https://place.map.kakao.com/11996067');
insert into total values('크랩잭 제주','126.3818406','33.48550435','https://place.map.kakao.com/1002205104');
insert into total values('안녕협재씨 제주협재점','126.2249782','33.3865667','https://place.map.kakao.com/1614966348');
insert into total values('싱싱잇','126.2272283','33.38639706','https://place.map.kakao.com/185672683');
insert into total values('곱들락','126.6702244','33.53948397','https://place.map.kakao.com/26976789');
insert into total values('산지물 본점','126.5274744','33.51628859','https://place.map.kakao.com/14491336');
insert into total values('고등어쌈밥','126.9207489','33.44945633','https://place.map.kakao.com/10015746');
insert into total values('황해식당','126.4306894','33.49235814','https://place.map.kakao.com/1995242586');
insert into total values('제주순풍 신제주본점','126.480644','33.475352','https://place.map.kakao.com/1958580481');
insert into total values('애월그때그집','126.3242436','33.46632007','https://place.map.kakao.com/932479755');
insert into total values('은희네해장국 2호점','126.5002822','33.4814048','https://place.map.kakao.com/994067083');
insert into total values('공천포식당','126.6425852','33.26638915','https://place.map.kakao.com/8204729');
insert into total values('월정리갈비밥','126.7968248','33.55475489','https://place.map.kakao.com/656489562');
insert into total values('순수한둠비','126.5143821','33.51111637','https://place.map.kakao.com/779594348');
insert into total values('덤장 중문점','126.4081843','33.25770481','https://place.map.kakao.com/8258838');
insert into total values('만월당','126.7929746','33.55619859','https://place.map.kakao.com/1879206540');
insert into total values('갈치요리전문점 만족한상회','126.4267293','33.25350324','https://place.map.kakao.com/489037210');
insert into total values('봉순이네흑돼지','126.2795731','33.27777282','https://place.map.kakao.com/26922347');
insert into total values('제주국담','126.4947098','33.48861002','https://place.map.kakao.com/767769697');
insert into total values('제주약수터 본점','126.5616317','33.24778351','https://place.map.kakao.com/1510813713');
insert into total values('더꽃돈 협재점','126.2425493','33.39533654','https://place.map.kakao.com/26305070');
insert into total values('골목','126.6617375','33.54386083','https://place.map.kakao.com/19413520');
insert into total values('오현돼지불백','126.5296073','33.51102228','https://place.map.kakao.com/22173396');
insert into total values('대기정','126.4285546','33.2402796','https://place.map.kakao.com/15383715');
insert into total values('신해바라기분식 본점','126.5259384','33.51421222','https://place.map.kakao.com/13595461');
insert into total values('하원가흑돼지','126.4487512','33.24269553','https://place.map.kakao.com/1480065759');
insert into total values('재벌식당','126.4843759','33.49079063','https://place.map.kakao.com/10726776');
insert into total values('공항흑돼지 시청그때그집','126.5288986','33.50193896','https://place.map.kakao.com/1454069536');
insert into total values('부촌','126.9168869','33.44885872','https://place.map.kakao.com/10471937');
insert into total values('제주육대표','126.4901205','33.49404387','https://place.map.kakao.com/870813459');
insert into total values('코코마마 성산점','126.9343196','33.46101665','https://place.map.kakao.com/787179341');
insert into total values('제주본참숯불갈비','126.4837669','33.48412169','https://place.map.kakao.com/8505828');
insert into total values('제주한라국수','126.4244178','33.25028472','https://place.map.kakao.com/27447640');
insert into total values('88버거','126.5671242','33.24924991','https://place.map.kakao.com/27559019');
insert into total values('미스칠','126.4833552','33.49391189','https://place.map.kakao.com/182376522');
insert into total values('오가네전복설렁탕','126.5895165','33.26819123','https://place.map.kakao.com/19143360');
insert into total values('코코분식','126.5299874','33.49679197','https://place.map.kakao.com/8101542');
insert into total values('임금님밥상','126.4609429','33.4848851','https://place.map.kakao.com/1717489231');
insert into total values('재연식당','126.8560084','33.52619354','https://place.map.kakao.com/24122989');
insert into total values('시흥해녀의집','126.9083015','33.47797932','https://place.map.kakao.com/9191583');
insert into total values('제주늘봄','126.4715593','33.47979778','https://place.map.kakao.com/8067674');
insert into total values('장수물식당','126.498612','33.49191213','https://place.map.kakao.com/11170411');
insert into total values('물항식당 본점','126.5290831','33.51692118','https://place.map.kakao.com/7875124');
insert into total values('큰돈가 본점','126.291007','33.2084603','https://place.map.kakao.com/780607372');
insert into total values('형돈','126.5329191','33.48932791','https://place.map.kakao.com/1176459440');
insert into total values('선흘곶','126.7180002','33.50820593','https://place.map.kakao.com/19934545');
insert into total values('제주돗','126.2308534','33.33314215','https://place.map.kakao.com/287748982');
insert into total values('뚱보아저씨','126.2553586','33.33063592','https://place.map.kakao.com/839698275');
insert into total values('황금어장','126.4953559','33.48439205','https://place.map.kakao.com/8690519');
insert into total values('민경이네어등포해녀촌','126.8257546','33.5537388','https://place.map.kakao.com/16260879');
insert into total values('토끼와거북이','126.4921242','33.51881877','https://place.map.kakao.com/8563496');
insert into total values('연정식당','126.4867703','33.4837912','https://place.map.kakao.com/9251493');
insert into total values('돈블랙 서귀포본점','126.5149987','33.24871602','https://place.map.kakao.com/375676806');
insert into total values('중문흑돼지천국','126.436983','33.23977243','https://place.map.kakao.com/184274845');
insert into total values('한라전복','126.2451931','33.23048137','https://place.map.kakao.com/1980729179');
insert into total values('제주고집','126.4848307','33.51095997','https://place.map.kakao.com/1266175207');
insert into total values('짱구분식','126.5671452','33.2501734','https://place.map.kakao.com/19358629');
insert into total values('우정회센타','126.5632179','33.24964781','https://place.map.kakao.com/25047828');
insert into total values('용두암해촌','126.5027317','33.51699033','https://place.map.kakao.com/11195814');
insert into total values('신의한모','126.4081183','33.4855334','https://place.map.kakao.com/27107805');
insert into total values('정가네밥상','126.5387593','33.46843081','https://place.map.kakao.com/2033616575');
insert into total values('남양수산','126.9140912','33.45019965','https://place.map.kakao.com/16525091');
insert into total values('신엄해녀의집','126.3668952','33.47846338','https://place.map.kakao.com/9566466');
insert into total values('협재칼국수','126.2444594','33.39681469','https://place.map.kakao.com/713350813');
insert into total values('대춘해장국 본점','126.5238809','33.48037768','https://place.map.kakao.com/209751725');
insert into total values('성미가든','126.6767768','33.4377539','https://place.map.kakao.com/10478618');
insert into total values('돌집식당','126.8004356','33.39395676','https://place.map.kakao.com/10313982');
insert into total values('바다를본돼지 제주노형점','126.4761911','33.48816077','https://place.map.kakao.com/27536957');
insert into total values('대우정','126.5195754','33.49891069','https://place.map.kakao.com/7830516');
insert into total values('산지물 신제주점','126.4909996','33.49081552','https://place.map.kakao.com/14683864');
insert into total values('김지순의낭푼밥상','126.5012892','33.49694516','https://place.map.kakao.com/461013758');
insert into total values('램앤블랙','126.6731134','33.43679603','https://place.map.kakao.com/471417273');
insert into total values('돈사돈 별관','126.4707126','33.48165662','https://place.map.kakao.com/291271136');
insert into total values('포도원흑돼지','126.4846814','33.46818336','https://place.map.kakao.com/18601309');
insert into total values('덕승식당','126.2512495','33.21927284','https://place.map.kakao.com/2080847055');
insert into total values('정직한돈 협재직영점','126.2503348','33.38910977','https://place.map.kakao.com/798042705');
insert into total values('홍성방','126.2516864','33.22010131','https://place.map.kakao.com/16841033');
insert into total values('경미네집','126.933503','33.46123723','https://place.map.kakao.com/21931852');
insert into total values('논짓물','126.4921684','33.48864692','https://place.map.kakao.com/17869257');
insert into total values('남경미락','126.3088108','33.23022633','https://place.map.kakao.com/21350388');
insert into total values('오조해녀의집','126.9222929','33.46973493','https://place.map.kakao.com/8016700');
insert into total values('제주미담','126.5372811','33.5023426','https://place.map.kakao.com/27207846');
insert into total values('가람돌솥밥','126.4312975','33.24966307','https://place.map.kakao.com/10954053');
insert into total values('제주김만복 성산점','126.9298667','33.46059371','https://place.map.kakao.com/1300092065');
insert into total values('문개항아리 애월점','126.3924383','33.48578441','https://place.map.kakao.com/879542502');
insert into total values('제주예찬','126.4868801','33.45407285','https://place.map.kakao.com/27221687');
insert into total values('백리향','126.6384241','33.53698385','https://place.map.kakao.com/23470769');
insert into total values('문치비','126.506024','33.25286689','https://place.map.kakao.com/26397051');
insert into total values('돈사돈 중문점','126.4330491','33.25099945','https://place.map.kakao.com/25890705');
insert into total values('연미정','126.85384','33.52463091','https://place.map.kakao.com/18352760');
insert into total values('도두반점 제주사수본점','126.4791818','33.50956745','https://place.map.kakao.com/809665221');
insert into total values('표선우동가게','126.8312909','33.32410987','https://place.map.kakao.com/2090669998');
insert into total values('삼미횟집','126.4637291','33.50460944','https://place.map.kakao.com/8491412');
insert into total values('도갈비','126.4792991','33.47652361','https://place.map.kakao.com/599236130');
insert into total values('성산일출봉 청운식당','126.9348788','33.46304183','https://place.map.kakao.com/8577081');
insert into total values('범일분식','126.7169254','33.27847318','https://place.map.kakao.com/17682261');
insert into total values('이스트포레스트','126.8987682','33.4958867','https://place.map.kakao.com/30139815');
insert into total values('덕성원 본점','126.5633852','33.24490479','https://place.map.kakao.com/15838018');
insert into total values('교래손칼국수','126.6759913','33.43613422','https://place.map.kakao.com/8193875');
insert into total values('나원회포차','126.5674754','33.24966068','https://place.map.kakao.com/1314424272');
insert into total values('윤옥','126.5357438','33.48916503','https://place.map.kakao.com/1010408190');
insert into total values('솔동산고기국수','126.5652195','33.24293997','https://place.map.kakao.com/23825088');
insert into total values('놀맨','126.3101928','33.46246569','https://place.map.kakao.com/21531714');
insert into total values('옥돔식당','126.2489989','33.2199751','https://place.map.kakao.com/9940398');
insert into total values('노조미','126.4902486','33.47953207','https://place.map.kakao.com/259228710');
insert into total values('낭쿰낭쿰','126.5607601','33.25174326','https://place.map.kakao.com/500756909');
insert into total values('산방산초가집','126.3386','33.24548348','https://place.map.kakao.com/12974776');
insert into total values('광명식당','126.5282415','33.51208719','https://place.map.kakao.com/19054447');
insert into total values('제갈양','126.2244264','33.38602666','https://place.map.kakao.com/25851685');
insert into total values('섬돼지','126.5124709','33.25072878','https://place.map.kakao.com/1862055456');
insert into total values('탐라우돈정육식당','126.4757484','33.49096656','https://place.map.kakao.com/16259948');
insert into total values('순옥이네명가 함덕점','126.6739833','33.54061955','https://place.map.kakao.com/785440933');
insert into total values('연북로해물탕','126.5054929','33.48239942','https://place.map.kakao.com/844447638');
insert into total values('해심가든','126.4265278','33.2519287','https://place.map.kakao.com/8608467');
insert into total values('금박돈','126.9336429','33.46134394','https://place.map.kakao.com/1466968220');
insert into total values('낭뜰에쉼팡','126.6571262','33.47355717','https://place.map.kakao.com/8874256');
insert into total values('춘미향식당','126.2964756','33.23142782','https://place.map.kakao.com/20125337');
insert into total values('숙성도 중문점','126.4075102','33.25833367','https://place.map.kakao.com/204534740');
insert into total values('만선식당','126.2497901','33.21786589','https://place.map.kakao.com/16260200');
insert into total values('인디언키친','126.3314292','33.45043347','https://place.map.kakao.com/1750377035');
insert into total values('칠돈가 서광직영점','126.3035164','33.28639913','https://place.map.kakao.com/1963115809');
insert into total values('제주해물밥','126.4339579','33.49470195','https://place.map.kakao.com/23641919');
insert into total values('해월정 서귀포점','126.2917748','33.21119374','https://place.map.kakao.com/1123715527');
insert into total values('돈고팡 본점','126.4722315','33.50892707','https://place.map.kakao.com/1708273489');
insert into total values('으뜨미식당','126.7870889','33.47068271','https://place.map.kakao.com/550011314');
insert into total values('스시도모다찌 제주점','126.5291769','33.49996713','https://place.map.kakao.com/12748422');
insert into total values('송림반점','126.5197328','33.51240112','https://place.map.kakao.com/20807210');
insert into total values('하하호호 우도본점','126.9484725','33.52083235','https://place.map.kakao.com/21531701');
insert into total values('형제도식당 본점','126.4128156','33.25778038','https://place.map.kakao.com/2014412408');
insert into total values('협재해녀의집','126.2438988','33.39883152','https://place.map.kakao.com/20198888');
insert into total values('옹포바다횟집','126.2516615','33.40385225','https://place.map.kakao.com/1582336126');
insert into total values('짬뽕에취한날','126.497863','33.49111356','https://place.map.kakao.com/24506094');
insert into total values('돈카츠서황','126.3798112','33.43446302','https://place.map.kakao.com/27609941');
insert into total values('제주곰집','126.4907702','33.23490687','https://place.map.kakao.com/20631993');
insert into total values('알동네집','126.2671842','33.31663901','https://place.map.kakao.com/24797226');
insert into total values('곤밥2','126.5276567','33.5148503','https://place.map.kakao.com/2007313797');
insert into total values('커큐민흑돼지','126.9211219','33.44979071','https://place.map.kakao.com/24910446');
insert into total values('더스푼','126.5411504','33.49340089','https://place.map.kakao.com/1802546975');
insert into total values('태하횟집','126.5152091','33.51663578','https://place.map.kakao.com/1257724094');
insert into total values('칠돈가 표선직영점','126.8440456','33.3258668','https://place.map.kakao.com/26418624');
insert into total values('돈향기','126.5270106','33.51582046','https://place.map.kakao.com/12542076');
insert into total values('모이세해장국 본점','126.5054929','33.48239942','https://place.map.kakao.com/7868089');
insert into total values('서서방숯불닭갈비','126.4902458','33.48661315','https://place.map.kakao.com/1432881641');
insert into total values('은희네해장국','126.4317201','33.25109745','https://place.map.kakao.com/995569353');
insert into total values('아서원','126.6179508','33.25440686','https://place.map.kakao.com/7989149');
insert into total values('노형삼대국수회관','126.4787655','33.48284378','https://place.map.kakao.com/12427764');
insert into total values('어조횟집','126.9308193','33.46044141','https://place.map.kakao.com/9238034');
insert into total values('종달수다뜰','126.8931026','33.4918916','https://place.map.kakao.com/11939834');
insert into total values('양가형제','126.2540199','33.30735566','https://place.map.kakao.com/27477200');
insert into total values('칠돈가 성산직영점','126.9169476','33.46812021','https://place.map.kakao.com/1614369304');
insert into total values('뚱딴지','126.3549861','33.4747632','https://place.map.kakao.com/16573450');
insert into total values('스시권','126.4779232','33.48542767','https://place.map.kakao.com/300984218');
insert into total values('그리운바다 성산포','126.9300436','33.46974149','https://place.map.kakao.com/18277817');
insert into total values('제주올래국수','126.5059918','33.50090733','https://place.map.kakao.com/559359242');
insert into total values('섭지코지해녀밥상','126.9175305','33.43576536','https://place.map.kakao.com/24856855');
insert into total values('바다풍경','126.5068461','33.5161756','https://place.map.kakao.com/17599331');
insert into total values('돈사돈 월정점','126.8274335','33.54134634','https://place.map.kakao.com/628037144');
insert into total values('기억나는집','126.5621708','33.24510426','https://place.map.kakao.com/8238096');
insert into total values('대원가','126.5269437','33.49155161','https://place.map.kakao.com/15200040');
insert into total values('동백별장','126.4814763','33.48676803','https://place.map.kakao.com/203710945');
insert into total values('탐라가든','126.5202969','33.50778445','https://place.map.kakao.com/10817173');
insert into total values('달이뜨는식탁','126.7908025','33.55316921','https://place.map.kakao.com/1229834384');
insert into total values('글라글라하와이','126.2513261','33.2195487','https://place.map.kakao.com/622958459');
insert into total values('흑본오겹 함덕점','126.6587103','33.54363737','https://place.map.kakao.com/1317601096');
insert into total values('섬소나이','126.9574476','33.51322456','https://place.map.kakao.com/24213584');
insert into total values('어박사 한림본점','126.2579773','33.40783771','https://place.map.kakao.com/1493057593');
insert into total values('성산고궁보말손칼국수','126.9346392','33.464202','https://place.map.kakao.com/201726827');
insert into total values('올레마당','126.3087886','33.23315178','https://place.map.kakao.com/27575771');
insert into total values('애월연어','126.3956872','33.42565848','https://place.map.kakao.com/1850519804');
insert into total values('꽃가람','126.9149614','33.4509016','https://place.map.kakao.com/1113932348');
insert into total values('뽈살집 한림점','126.269249','33.41566017','https://place.map.kakao.com/19365035');
insert into total values('순풍해장국 함덕본점','126.6739845','33.5398586','https://place.map.kakao.com/25621205');
insert into total values('곽지해녀의집','126.3066102','33.45378208','https://place.map.kakao.com/12507919');
insert into total values('검은쇠몰고오는','126.4933707','33.48358109','https://place.map.kakao.com/18767827');
insert into total values('고미','126.5575307','33.2492013','https://place.map.kakao.com/15861671');
insert into total values('한라전복','126.9169784','33.47096267','https://place.map.kakao.com/10112205');
insert into total values('성산 갈치조림 순덕이네','126.8965833','33.41222562','https://place.map.kakao.com/9159798');
insert into total values('서광보말칼국수','126.32206','33.28922424','https://place.map.kakao.com/135431578');
insert into total values('잇칸시타','126.3702414','33.4770858','https://place.map.kakao.com/1365667514');
insert into total values('중문색달통갈치','126.404528','33.2583638','https://place.map.kakao.com/1602465884');
insert into total values('센트로','126.5675723','33.24666241','https://place.map.kakao.com/347012105');
insert into total values('삼다도횟집 본점','126.4992722','33.51902437','https://place.map.kakao.com/8341034');
insert into total values('바로족발보쌈','126.4793523','33.47887236','https://place.map.kakao.com/24975923');
insert into total values('제주영롱가','126.5487232','33.46984135','https://place.map.kakao.com/953967640');
insert into total values('용두암오메기떡','126.5106399','33.51295232','https://place.map.kakao.com/171171889');
insert into total values('성읍칠십리식당','126.8013714','33.38929442','https://place.map.kakao.com/18653628');
insert into total values('제주오누이','126.8278533','33.54286504','https://place.map.kakao.com/81111860');
insert into total values('수영밥상 본점','126.4296315','33.48609538','https://place.map.kakao.com/581577829');
insert into total values('회춘','126.6625887','33.54313044','https://place.map.kakao.com/420806106');
insert into total values('귤품은흑돼지 제주공항점','126.4639019','33.50636734','https://place.map.kakao.com/707271185');
insert into total values('담다','126.2412348','33.39389596','https://place.map.kakao.com/149733490');
insert into total values('마마무말가든','126.508062','33.4723614','https://place.map.kakao.com/234355435');
insert into total values('요기소바 본점','126.4833339','33.48542816','https://place.map.kakao.com/1193174165');
insert into total values('참맛나김밥','126.4750213','33.4786179','https://place.map.kakao.com/1750206688');
insert into total values('강식당','126.2434837','33.39783857','https://place.map.kakao.com/2131874405');
insert into total values('제주곱','126.4923224','33.48708669','https://place.map.kakao.com/1748613204');
insert into total values('어멍횟집','126.9157839','33.44788393','https://place.map.kakao.com/19644570');
insert into total values('칠돈가 제주공항직영점','126.4958202','33.48449728','https://place.map.kakao.com/1238978117');
insert into total values('흑돼지패밀리','126.6510214','33.28825304','https://place.map.kakao.com/265658260');
insert into total values('까망돼지 서귀포점','126.5774975','33.25514941','https://place.map.kakao.com/27357703');
insert into total values('앞뱅디식당','126.4999366','33.48536935','https://place.map.kakao.com/10591316');
insert into total values('제주선채향','126.299093','33.22636176','https://place.map.kakao.com/1612962916');
insert into total values('도민상회','126.2602588','33.41329787','https://place.map.kakao.com/209205830');
insert into total values('선흘방주할머니식당','126.7000949','33.48456366','https://place.map.kakao.com/21509975');
insert into total values('천돈가','126.4174305','33.25804956','https://place.map.kakao.com/1493568255');
insert into total values('소리원','126.5005416','33.49648459','https://place.map.kakao.com/20606563');
insert into total values('오가네 전복설렁탕 함덕점','126.6657402','33.542464','https://place.map.kakao.com/2145368679');
insert into total values('제주통큰장어','126.5421256','33.5015549','https://place.map.kakao.com/26614817');
insert into total values('맨도롱 해장국','126.5601035','33.24708197','https://place.map.kakao.com/17843839');
insert into total values('삼성혈해물탕 1호점','126.4653667','33.50389032','https://place.map.kakao.com/26927065');
insert into total values('명랑스낵','126.2588389','33.40926014','https://place.map.kakao.com/27357866');
insert into total values('중문그때그집','126.3900823','33.26423922','https://place.map.kakao.com/552369116');
insert into total values('중문회포장센터 새벽야시장','126.4292688','33.24662864','https://place.map.kakao.com/1111784272');
insert into total values('올레삼다정','126.5698388','33.2530957','https://place.map.kakao.com/26845442');
insert into total values('삼대국수회관 신제주점','126.4932096','33.48384133','https://place.map.kakao.com/7910666');
insert into total values('제니의정원','126.4946008','33.49506908','https://place.map.kakao.com/24812560');
insert into total values('임순이네','126.3042111','33.44896873','https://place.map.kakao.com/27575902');
insert into total values('동복뚝배기','126.7093208','33.55318748','https://place.map.kakao.com/1936912017');
insert into total values('희야국수','126.4897221','33.50123679','https://place.map.kakao.com/925000785');
insert into total values('저팔계깡통연탄구이 본관','126.6666738','33.54170032','https://place.map.kakao.com/14719640');
insert into total values('제일수산횟집','126.5602951','33.25149965','https://place.map.kakao.com/1471703833');
insert into total values('문쏘','126.2565276','33.4055753','https://place.map.kakao.com/444905118');
insert into total values('만지식당','126.3390464','33.46325787','https://place.map.kakao.com/1060504714');
insert into total values('거멍국수','126.3043499','33.24460313','https://place.map.kakao.com/26908614');
insert into total values('스시도모다찌 칠성점','126.5258127','33.51347843','https://place.map.kakao.com/1755141351');
insert into total values('화성식당','126.5861141','33.52150058','https://place.map.kakao.com/10050832');
insert into total values('뜰에','126.3202123','33.46621864','https://place.map.kakao.com/775448775');
insert into total values('수복강녕','126.4993864','33.48840327','https://place.map.kakao.com/2076904700');
insert into total values('삼대전통고기국수','126.4986126','33.49297639','https://place.map.kakao.com/9810778');
insert into total values('산포식당','126.899692','33.44515415','https://place.map.kakao.com/23319358');
insert into total values('한라산아래첫마을','126.3795784','33.32824036','https://place.map.kakao.com/1710030150');
insert into total values('꽃밥','126.3085062','33.45154558','https://place.map.kakao.com/18311320');
insert into total values('피어22','126.2277789','33.38993245','https://place.map.kakao.com/2143131680');
insert into total values('중문신라원','126.5119814','33.23436697','https://place.map.kakao.com/17079132');
insert into total values('중문해녀의집','126.418992','33.24321609','https://place.map.kakao.com/25046156');
insert into total values('운산식당','126.5219123','33.51594031','https://place.map.kakao.com/2136748338');
insert into total values('돌하르방식당 본점','126.5387279','33.51006304','https://place.map.kakao.com/8257171');
insert into total values('한라축산정육식당','126.4858371','33.46585461','https://place.map.kakao.com/1879164164');
insert into total values('정이가네','126.5111259','33.25196053','https://place.map.kakao.com/889033877');
insert into total values('동성수산횟집','126.2520938','33.21649213','https://place.map.kakao.com/24119776');
insert into total values('코시롱','126.373444','33.47946783','https://place.map.kakao.com/218595252');
insert into total values('슬슬슬로우','126.7930434','33.53039471','https://place.map.kakao.com/27465479');
insert into total values('황금손가락','126.4858924','33.4512857','https://place.map.kakao.com/20315151');
insert into total values('연탄과친한돼지','126.4850283','33.4831907','https://place.map.kakao.com/20054329');
insert into total values('옛날국수집','126.403312','33.48029041','https://place.map.kakao.com/1796418844');
insert into total values('용담밭담','126.5099543','33.50112846','https://place.map.kakao.com/727076726');
insert into total values('알동네집 화순점','126.3406934','33.25358536','https://place.map.kakao.com/256756454');
insert into total values('전망대횟집','126.2609542','33.42306222','https://place.map.kakao.com/9932430');
insert into total values('뱃도새기 흑돼지','126.6745637','33.53940366','https://place.map.kakao.com/1130310479');
insert into total values('참좋은해물라면 애월점','126.3781439','33.48385085','https://place.map.kakao.com/26355125');
insert into total values('미풍해장국 코스모스점','126.496945','33.48548497','https://place.map.kakao.com/8320316');
insert into total values('갈치공장','126.8509609','33.53190352','https://place.map.kakao.com/1942763932');
insert into total values('영빈횟집','126.5678652','33.24327777','https://place.map.kakao.com/21509585');
insert into total values('모메존흑돼지','126.8543803','33.52537332','https://place.map.kakao.com/530944208');
insert into total values('대춘해장국 노형점','126.4844532','33.48762447','https://place.map.kakao.com/2097782769');
insert into total values('흑돼지제주정','126.8438465','33.32484094','https://place.map.kakao.com/2028945513');
insert into total values('만장굴','126.7691994','33.52790795','https://place.map.kakao.com/7863269'');
insert into total values('용천동굴','126.778367','33.54848435','https://place.map.kakao.com/12658130'');
insert into total values('황우지해안열두굴','126.5507756','33.2419643','https://place.map.kakao.com/8169612'');
insert into total values('송악산 진지동굴','126.2758093','33.21828142','https://place.map.kakao.com/8433844'');
insert into total values('한림공원 협재굴','126.2497902','33.38199861','https://place.map.kakao.com/11200482'');
insert into total values('일출랜드 미천굴','126.8409964','33.38370597','https://place.map.kakao.com/17574894');
insert into total values('김녕사굴','126.7755329','33.54387086','https://place.map.kakao.com/8194588');
insert into total values('도저굴','126.5016723','33.50501511','https://place.map.kakao.com/10306072');
insert into total values('신비동굴','126.791736','33.38138152','https://place.map.kakao.com/2051738530');
insert into total values('진지동굴','126.3487669','33.24461218','https://place.map.kakao.com/1466727511');
insert into total values('한림공원 쌍용굴','126.2497902','33.38199861','https://place.map.kakao.com/17808197');
insert into total values('용암동굴지대','126.2389823','33.38853492','https://place.map.kakao.com/8466104');
insert into total values('들렁궤','126.4151925','33.30037838','https://place.map.kakao.com/13723650');
insert into total values('녹차동굴','126.7869416','33.38160134','https://place.map.kakao.com/1714785831');
insert into total values('동안경굴','126.9663248','33.49545294','https://place.map.kakao.com/26973777');
insert into total values('중동굴','126.866145','33.47544319','https://place.map.kakao.com/8071141');
insert into total values('지중굴','126.3368934','33.46301769','https://place.map.kakao.com/8087937');
insert into total values('목시물굴','126.7183095','33.53159363','https://place.map.kakao.com/7877823');
insert into total values('만장굴','126.7691994','33.52790795','https://place.map.kakao.com/7863269');
insert into total values('와흘굴','126.6322986','33.50606516','https://place.map.kakao.com/520426778');
insert into total values('정타굴','126.3836926','33.44649249','https://place.map.kakao.com/1491752891');
insert into total values('북촌동굴','126.7011961','33.54844477','https://place.map.kakao.com/8580695');
insert into total values('생수동굴','126.3204621','33.35125594','https://place.map.kakao.com/8498835');
insert into total values('거먹남굴','126.8610305','33.49390458','https://place.map.kakao.com/7912596');
insert into total values('제주서우봉 일제동굴진지','126.6800913','33.55149003','https://place.map.kakao.com/26633974');
insert into total values('제주송악산외륜 일제동굴진지','126.2873633','33.20298173','https://place.map.kakao.com/26916283');
insert into total values('제주사라봉 일제동굴진지','126.5458078','33.51770452','https://place.map.kakao.com/26916266');
insert into total values('별도봉 일본군 진지동굴','126.5530365','33.51683725','https://place.map.kakao.com/1222946236');
insert into total values('국립제주박물관','126.5479099','33.51379681','https://place.map.kakao.com/8192179');
insert into total values('세계자동차피아노박물관','126.3496279','33.28287613','https://place.map.kakao.com/7952882');
insert into total values('박물관은살아있다 제주중문점','126.409767','33.25489681','https://place.map.kakao.com/17583646');
insert into total values('제주항공우주박물관','126.3016193','33.3037596','https://place.map.kakao.com/19585161');
insert into total values('헬로키티아일랜드','126.352081','33.29009959','https://place.map.kakao.com/26608807');
insert into total values('제주특별자치도 민속자연사박물관','126.5315229','33.50651201','https://place.map.kakao.com/8067497');
insert into total values('피규어뮤지엄제주','126.3553561','33.28190307','https://place.map.kakao.com/1608663587');
insert into total values('넥슨컴퓨터박물관','126.485584','33.47202077','https://place.map.kakao.com/20303776');
insert into total values('해녀박물관','126.8630469','33.52274845','https://place.map.kakao.com/17600341');
insert into total values('감귤박물관','126.6074293','33.27159405','https://place.map.kakao.com/23972751');
insert into total values('제주해양동물박물관','126.8551275','33.42948565','https://place.map.kakao.com/819488120');
insert into total values('석부작박물관','126.5370605','33.25062623','https://place.map.kakao.com/7944019');
insert into total values('바이나흐튼 크리스마스박물관','126.3281572','33.29126409','https://place.map.kakao.com/495587934');
insert into total values('제주커피박물관 바움','126.899212','33.43987431','https://place.map.kakao.com/26428769');
insert into total values('세계술박물관','126.8176639','33.35419967','https://place.map.kakao.com/24860542');
insert into total values('아프리카박물관','126.4288245','33.23999105','https://place.map.kakao.com/7991509');
insert into total values('세계조가비박물관','126.5516316','33.24744608','https://place.map.kakao.com/12887024');
insert into total values('제주교육박물관','126.5384117','33.4942962','https://place.map.kakao.com/10799984');
insert into total values('조안베어뮤지엄','126.4341088','33.2402484','https://place.map.kakao.com/8520885');
insert into total values('조랑말박물관','126.736285','33.38309563','https://place.map.kakao.com/22854993');
insert into total values('예나르제주공예박물관','126.2669212','33.34002402','https://place.map.kakao.com/1656659819');
insert into total values('제주요도자기문화박물관','126.4420713','33.45743475','https://place.map.kakao.com/9402759');
insert into total values('제주대학교 박물관','126.5567759','33.45174268','https://place.map.kakao.com/18983511');
insert into total values('국립제주박물관 복합문화전시관','126.5479099','33.51379681','https://place.map.kakao.com/760081345');
insert into total values('더마파크','126.2435622','33.35419435','https://place.map.kakao.com/11470870');
insert into total values('조랑말체험공원','126.736285','33.38309563','https://place.map.kakao.com/18574207');
insert into total values('탐라승마장','126.7172031','33.43351391','https://place.map.kakao.com/10820078');
insert into total values('중문승마공원','126.4455562','33.24256476','https://place.map.kakao.com/600432495');
insert into total values('제주승마공원','126.4061874','33.40584632','https://place.map.kakao.com/8950356');
insert into total values('삼다수목장','126.6652392','33.43239582','https://place.map.kakao.com/1032410621');
insert into total values('제주오름승마랜드','126.7134438','33.448973','https://place.map.kakao.com/27418655');
insert into total values('제주조랑말타운','126.7726749','33.40754397','https://place.map.kakao.com/15313432');
insert into total values('옷귀마테마타운 승마장','126.6834249','33.34046898','https://place.map.kakao.com/26647270');
insert into total values('송당승마장','126.7377594','33.43594073','https://place.map.kakao.com/11287687');
insert into total values('어승생승마장','126.4904124','33.42576456','https://place.map.kakao.com/7997639');
insert into total values('제주홀스타승마장','126.4938235','33.42238185','https://place.map.kakao.com/22510509');
insert into total values('우리 승마장','126.8130203','33.38684524','https://place.map.kakao.com/15518256');
insert into total values('쇠와꽃승마장','126.920006','33.44731522','https://place.map.kakao.com/24126060');
insert into total values('OK승마장','126.7833016','33.40269586','https://place.map.kakao.com/17385264');
insert into total values('제주승마장','126.7189664','33.43467049','https://place.map.kakao.com/24946711');
insert into total values('알프스승마장포니','126.8030616','33.39879473','https://place.map.kakao.com/18647283');
insert into total values('조은승마장','126.345112','33.31830003','https://place.map.kakao.com/19499632');
insert into total values('이어도관광승마장','126.8205716','33.40753374','https://place.map.kakao.com/11172974');
insert into total values('홀스스토리승마장','126.3438862','33.42618872','https://place.map.kakao.com/916744324');
insert into total values('세리승마','126.5125703','33.24720295','https://place.map.kakao.com/26102875');
insert into total values('산도스카발리오홀스파크','126.3708165','33.33398399','https://place.map.kakao.com/488546136');
insert into total values('아덴힐승마클럽','126.4671988','33.44835813','https://place.map.kakao.com/342978436');
insert into total values('웅지승마센터','126.3797014','33.39092235','https://place.map.kakao.com/27052490');
insert into total values('운주승마클럽','126.6795642','33.47390281','https://place.map.kakao.com/1868560755');
insert into total values('앨리샤승마장','126.9606473','33.49274468','https://place.map.kakao.com/25681667');
insert into total values('제주승마스쿨','126.4253903','33.47583224','https://place.map.kakao.com/355269587');
insert into total values('성읍승마장','126.7874142','33.39808469','https://place.map.kakao.com/15270363');
insert into total values('힐링팜 농어촌승마교육장','126.3160324','33.37862448','https://place.map.kakao.com/136310620');
insert into total values('탑홀스 신제주점','126.4868986','33.48409077','https://place.map.kakao.com/27088364');
insert into total values('한라승마장','126.3529738','33.3238238','https://place.map.kakao.com/9602954');
insert into total values('에이원승마클럽','126.4138581','33.41945144','https://place.map.kakao.com/25510239');
insert into total values('탑홀스 서귀점','126.5746727','33.25814879','https://place.map.kakao.com/24532588');
insert into total values('홀스홀릭','126.3167221','33.36510245','https://place.map.kakao.com/697789971');
insert into total values('마원','126.6999558','33.49112657','https://place.map.kakao.com/1143443141');
insert into total values('제주그린파크 승마장','126.7442212','33.36101231','https://place.map.kakao.com/27544738');
insert into total values('아일랜드승마장','126.8499769','33.42397715','https://place.map.kakao.com/17988351');
insert into total values('에덴승마장','126.4536496','33.28609325','https://place.map.kakao.com/10574085');
insert into total values('제이앤승마클럽','126.4689814','33.44607296','https://place.map.kakao.com/1228597936');
insert into total values('라온승마클럽','126.2432723','33.35433126','https://place.map.kakao.com/26046071');
insert into total values('마패승마동호회','126.4750651','33.44941416','https://place.map.kakao.com/322082631');
insert into total values('아리온승마장','126.3340084','33.31102038','https://place.map.kakao.com/113667955');
insert into total values('홀스랜드','126.4904124','33.42576456','https://place.map.kakao.com/939696286');
insert into total values('라이더스랩','126.8302945','33.39145278','https://place.map.kakao.com/1624112598');
insert into total values('서진승마장','126.7240161','33.43417563','https://place.map.kakao.com/7943055');
insert into total values('브리더스파크 희망홀스승마클럽','126.7777874','33.43485488','https://place.map.kakao.com/561813737');
insert into total values('서귀포산업과학고등학교 승마장','126.5829296','33.2980864','https://place.map.kakao.com/1496215958');
insert into total values('거문오름승마장','126.7002167','33.4907066','https://place.map.kakao.com/703467592');
insert into total values('명도암승마장','126.6096377','33.46298827','https://place.map.kakao.com/10330897');
insert into total values('우도관광마차','126.9677943','33.51479157','https://place.map.kakao.com/8030933');
insert into total values('코리아호스랜드','126.7552717','33.37424226','https://place.map.kakao.com/880338512');
insert into total values('노을승마장','126.9464384','33.51294586','https://place.map.kakao.com/26254227');
insert into total values('말산업협동조합','126.3588685','33.39618457','https://place.map.kakao.com/1637924076');
insert into total values('제주드림랜드 승마장','126.363384','33.36270879','https://place.map.kakao.com/17806123');
insert into total values('징기스칸승마캠프','126.9634754','33.49289305','https://place.map.kakao.com/26070623');
insert into total values('한화넥스트','126.3768843','33.40008368','https://place.map.kakao.com/450230530');
insert into total values('뷰제주하늘','126.8328917','33.41301682','https://place.map.kakao.com/11153477');
insert into total values('탑승마클럽','126.6117418','33.46256259','https://place.map.kakao.com/14498054');
insert into total values('렛츠런파크제주 아름다운승마장','126.4011406','33.40355488','https://place.map.kakao.com/17582871');
insert into total values('나누리승마센터','126.6928593','33.46030658','https://place.map.kakao.com/12501731');
insert into total values('981파크','126.3662567','33.39079808','https://place.map.kakao.com/1868828759');
insert into total values('윈드1947카트테마파크','126.5888286','33.28951843','https://place.map.kakao.com/820826091');
insert into total values('메이즈랜드','126.8010739','33.48781022','https://place.map.kakao.com/13095815');
insert into total values('김녕미로공원','126.7720103','33.53647139','https://place.map.kakao.com/17110921');
insert into total values('브릭캠퍼스 제주','126.4844543','33.45823907','https://place.map.kakao.com/1826295011');
insert into total values('제주돌문화공원','126.6669316','33.43835559','https://place.map.kakao.com/13322621');
insert into total values('제주불빛정원','126.4094858','33.42167354','https://place.map.kakao.com/891104398');
insert into total values('에코랜드테마파크','126.6677887','33.45534587','https://place.map.kakao.com/21500227');
insert into total values('선녀와나무꾼 테마공원','126.7031221','33.47898324','https://place.map.kakao.com/12501734');
insert into total values('제주레포츠랜드','126.6388102','33.48219124','https://place.map.kakao.com/11714326');
insert into total values('소인국테마파크','126.3228448','33.2894473','https://place.map.kakao.com/11330871');
insert into total values('파더스가든','126.3657552','33.2799477','https://place.map.kakao.com/303901411');
insert into total values('서프라이즈테마파크','126.6598509','33.46555299','https://place.map.kakao.com/921324600');
insert into total values('액티브파크','126.2360797','33.3811438','https://place.map.kakao.com/627270178');
insert into total values('일출랜드','126.8409964','33.38370597','https://place.map.kakao.com/10399499');
insert into total values('바운스슈퍼파크 제주센터','126.5094227','33.48246579','https://place.map.kakao.com/965883722');
insert into total values('제주코코몽에코파크','126.705472','33.27517598','https://place.map.kakao.com/19388120');
insert into total values('오늘은카트레이싱','126.7905169','33.38156623','https://place.map.kakao.com/2096590');
insert into total values('세리월드','126.5120169','33.24701709','https://place.map.kakao.com/10472331');
insert into total values('성읍랜드','126.7869814','33.39849024','https://place.map.kakao.com/17382302');
insert into total values('액트몬 제주중문점','126.4216625','33.24388642','https://place.map.kakao.com/780499262');
insert into total values('물의도시 베니스랜드','126.8402184','33.41623648','https://place.map.kakao.com/23231118');
insert into total values('금능석물원','126.2264615','33.38562367','https://place.map.kakao.com/11023307');
insert into total values('신화워터파크','126.3163567','33.30497983','https://place.map.kakao.com/1870273669');
insert into total values('산방산랜드','126.3117697','33.23409754','https://place.map.kakao.com/11059651');
insert into total values('고스트타운','126.3571162','33.47605571','https://place.map.kakao.com/1129394481');
insert into total values('토이파크','126.3453625','33.31895851','https://place.map.kakao.com/17630155');
insert into total values('무병장수테마파크','126.361067','33.39528599','https://place.map.kakao.com/14513668');
insert into total values('세리월드 카트레이싱','126.5116606','33.24673454','https://place.map.kakao.com/11126147');
insert into total values('남원용암해수풀장','126.7196024','33.27781471','https://place.map.kakao.com/14087877');
insert into total values('제주포크테마파크','126.3895609','33.40913274','https://place.map.kakao.com/1304746374');
insert into total values('휘닉스제주섭지코지 바람의언덕','126.9322411','33.42704467','https://place.map.kakao.com/23150913');
insert into total values('고스트타운 고스트하우스','126.3571162','33.47605571','https://place.map.kakao.com/2132173808');
insert into total values('이상한나라의앨리스 서광카트장','126.3216873','33.28860303','https://place.map.kakao.com/17808836');
insert into total values('아쿠아플라넷제주 오션데크','126.926942','33.43345863','https://place.map.kakao.com/23121314');
insert into total values('신화테마파크 윙클스하우스','126.314351','33.30669689','https://place.map.kakao.com/620485575');
insert into total values('제주돌문화공원 별관휴게소','126.6571167','33.44727884','https://place.map.kakao.com/18119066');
insert into total values('수목원테마파크','126.488218','33.47065313','https://place.map.kakao.com/15106119');
insert into total values('무병장수테마파크 제주신시국궁장','126.361067','33.39528599','https://place.map.kakao.com/9370332');
insert into total values('무병장수테마파크 명상단식수련장','126.3602893','33.39519993','https://place.map.kakao.com/12706758');
insert into total values('이호테우해수욕장','126.4530343','33.49745487','https://place.map.kakao.com/8552559');
insert into total values('함덕해수욕장','126.6705076','33.54282298','https://place.map.kakao.com/8148451');
insert into total values('협재해수욕장','126.2395602','33.39384848','https://place.map.kakao.com/8159415');
insert into total values('용머리해안','126.300092','33.2344694','https://place.map.kakao.com/10706886');
insert into total values('금능해수욕장','126.2362052','33.39040068','https://place.map.kakao.com/13723603');
insert into total values('곽지해수욕장','126.3049021','33.4502301','https://place.map.kakao.com/25022153');
insert into total values('김녕해수욕장','126.7598385','33.55710644','https://place.map.kakao.com/25023085');
insert into total values('표선해수욕장','126.8276385','33.32403621','https://place.map.kakao.com/8640631');
insert into total values('사계해변','126.300092','33.2344694','https://place.map.kakao.com/11055702');
insert into total values('황우지해안','126.5503176','33.24166666','https://place.map.kakao.com/26974762');
insert into total values('월정리해수욕장','126.7986877','33.55509498','https://place.map.kakao.com/17600274');
insert into total values('세화해변','126.8622394','33.52337114','https://place.map.kakao.com/7964223');
insert into total values('중문색달해수욕장','126.4066695','33.24734359','https://place.map.kakao.com/8069764');
insert into total values('광치기해변','126.9239469','33.45230481','https://place.map.kakao.com/13723499');
insert into total values('삼양해수욕장','126.5856185','33.52559234','https://place.map.kakao.com/7934984');
insert into total values('남원큰엉해변','126.7037181','33.27335749','https://place.map.kakao.com/2083466041');
insert into total values('논짓물해변','126.380384','33.23944374','https://place.map.kakao.com/8232047');
insert into total values('하도해변','126.8856645','33.5143512','https://place.map.kakao.com/11340501');
insert into total values('검멀레해변','126.9550808','33.50770519','https://place.map.kakao.com/11041974');
insert into total values('평대리해수욕장','126.8276306','33.50834715','https://place.map.kakao.com/17600314');
insert into total values('신창풍차해안','126.1775667','33.34523307','https://place.map.kakao.com/25049180');
insert into total values('우도산호해변','126.9550808','33.50770519','https://place.map.kakao.com/7912384');
insert into total values('엉알해안','126.1867958','33.3013674','https://place.map.kakao.com/20056455');
insert into total values('하고수동해변','126.9550808','33.50770519','https://place.map.kakao.com/8132634');
insert into total values('종달리해변','126.9056411','33.48850656','https://place.map.kakao.com/18502101');
insert into total values('신양섭지해수욕장','126.9234522','33.43514028','https://place.map.kakao.com/10607235');
insert into total values('코난해변','126.811248','33.55753803','https://place.map.kakao.com/399094716');
insert into total values('하효쇠소깍해변','126.6225503','33.25153968','https://place.map.kakao.com/22924455');
insert into total values('몽돌해변','126.4401591','33.49595994','https://place.map.kakao.com/1851061731');
insert into total values('신흥해수욕장','126.6499948','33.5470118','https://place.map.kakao.com/14617439');
insert into total values('소금막해변','126.8276385','33.32403621','https://place.map.kakao.com/1932375305');
insert into total values('세기알해변','126.756348','33.55769127','https://place.map.kakao.com/1950858245');
insert into total values('알작지해변','126.4401591','33.49595994','https://place.map.kakao.com/13323388');
insert into total values('황우치해변','126.3170133','33.23902455','https://place.map.kakao.com/17806435');
insert into total values('광치기중간','126.90962','33.44069883','https://place.map.kakao.com/13723496');
insert into total values('우뭇개해안','126.9325961','33.46710421','https://place.map.kakao.com/1718571277');
insert into total values('수마포해안','126.9325961','33.46710421','https://place.map.kakao.com/13718563');
insert into total values('설쿰바당','126.300092','33.2344694','https://place.map.kakao.com/13723890');
insert into total values('모진이몽돌해변','126.333974','33.94608453','https://place.map.kakao.com/13723641');

select*from total;
select*from board;
select*from mem_info;
select*from mem_like;
select*from mem_map

commit;

update board set title = '이준호 수정', content = '수정 왜 안돼..', date = sysdate, division = 1 where seq = 10001;