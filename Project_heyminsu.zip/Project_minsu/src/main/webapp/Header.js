const nav = document.querySelector('.main')
fetch('/Header.jsp')
.then(res=>res.text())
.then(date=>{
    nav.innerHTML=date
})