const findIdBtn = document.getElementById("findId");
const findPwBtn = document.getElementById("findPw");
const fistForm = document.getElementById("form3");
const secondForm = document.getElementById("form4");
const container = document.querySelector(".container");

findIdBtn.addEventListener("click", () => {
	container.classList.remove("right-panel-active");
});

findPwBtn.addEventListener("click", () => {
	container.classList.add("right-panel-active");
});