$(document).ready(function(){
    console.clear();

    var slideIndex = 0;
    
    setInterval(function(){
        if(slideIndex > 15){
            slideIndex = 0;
        };
        $(".box-list").css({"top": -100 * slideIndex});
        
        console.log(slideIndex);
        slideIndex++;
            
        },2000)
    });