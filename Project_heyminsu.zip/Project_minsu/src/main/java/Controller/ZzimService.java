package Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.likeDAO;
import Model.likeDTO;
import Model.memberDAO;
import Model.memberDTO;

public class ZzimService extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 인코딩
		request.setCharacterEncoding("utf-8");

		// 회원정보 저장 세션 불러오기
		HttpSession session = request.getSession();
		memberDTO info = (memberDTO) session.getAttribute("info");

		// r_1, r_2, r_3 값 받아오기
		String r_1 = request.getParameter("r_1");
		String r_2 = request.getParameter("r_2");
		String r_3 = request.getParameter("r_3");

		String point = null;
		if (r_1 != null) {
			point = r_1;
		} else if (r_2 != null) {
			point = r_2;
		} else if (r_3 != null) {
			point = r_3;
		}

		boolean result = false;

		// likeDTO, likeDAO 호출
		likeDTO dto = new likeDTO(info.getNum(), info.getId(), point);
		likeDAO dao = new likeDAO();
		if (dao.likeadd(dto) > 0) {
			// 찜 목록 추가 성공 시
			result = true;
		}
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print(result);
	}
}
