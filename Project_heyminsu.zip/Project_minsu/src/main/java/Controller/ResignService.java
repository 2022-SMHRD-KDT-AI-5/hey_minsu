package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.memberDAO;
import Model.memberDTO;

public class ResignService extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 인코딩
		request.setCharacterEncoding("utf-8");

		// 기존 저장된 회원정보 session 호출
		HttpSession session = request.getSession();
		memberDTO info = (memberDTO) session.getAttribute("info");

		// pw, tx 값 받아오기
		String pw = request.getParameter("pw");
		String tx = request.getParameter("tx");

		// memberDTO, memberDAO 호출
		memberDTO dto = new memberDTO(info.getId(), pw);
		memberDAO dao = new memberDAO();

		String moveURL = null;

		if (tx.equals("탈퇴하겠습니다")) {
			if (dao.resign(dto) > 0) {
				// 회원탈퇴 성공 시
				session.removeAttribute("info");
				moveURL = "Main.jsp";
			} else {
				// 회원탈퇴 실패 시
				moveURL = "Resign.jsp";
				System.out.println(1);
			}
		} else {
			// 회원탈퇴 실패 시
			moveURL = "Resign.jsp";
			System.out.println(2);
		}
		response.sendRedirect(moveURL);
	}
}
