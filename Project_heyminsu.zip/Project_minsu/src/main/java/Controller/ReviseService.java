package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.memberDAO;
import Model.memberDTO;

public class ReviseService extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 인코딩
		request.setCharacterEncoding("utf-8");

		// 기존 저장된 회원정보 session 호출
		HttpSession session = request.getSession();
		memberDTO info = (memberDTO) session.getAttribute("info");

		// 수정할 pw, name, email 값 받아오기
		String pw = request.getParameter("pw1");
		String name = request.getParameter("name");
		String email = request.getParameter("email");

		// memberDTO, memberDAO 호출
		memberDTO dto = new memberDTO(info.getId(), pw, name, email);
		memberDAO dao = new memberDAO();

		String moveURL = null;

		if (dao.update(dto) > 0) {
			// 정보 수정 성공 시
			session.setAttribute("info", dto);
			moveURL = "Main.jsp";
		} else {
			// 정보 수정 실패 시
			moveURL = "Revise.jsp";
		}
		response.sendRedirect(moveURL);
	}
}
