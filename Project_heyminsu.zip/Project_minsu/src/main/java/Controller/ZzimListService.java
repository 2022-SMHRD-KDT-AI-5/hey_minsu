package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.likeDAO;
import Model.likeDTO;
import Model.memberDTO;

public class ZzimListService extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 인코딩
		request.setCharacterEncoding("utf-8");

		// 회원정보 저장 세션 불러오기
		HttpSession session = request.getSession();
		memberDTO info = (memberDTO) session.getAttribute("info");
		String text = "<li class='list'>찜목록</li>";

		// likeDTO, likeDAO 호출
		likeDAO dao = new likeDAO();
		ArrayList<likeDTO> list = dao.likelist(info.getId());

		if (list != null) {
			// 찜 목록 출력 성공 시
			for (int i = 0; i < list.size(); i++) {
				text += "<li class='list' style='background=\"red\"'><a href='" + "주소" + "'>" + list.get(i).getPoint() + "</a>";

				if(list.get(i).getLike_check() == 0) {
					text += "<input type='button' class='likebtn1 gido' value='지도추가' onclick='MapAdd("
							+ list.get(i).getLike_num() + ")'>";
				} else {
					text += "<input type='button' class='likebtn2 gido' value='지도삭제' onclick='MapDelete("
							+ list.get(i).getLike_num() + ")'>";
				}
				text += "<input type='button' class='Zzimdel' value='찜삭제' onclick='ZzimDelete("
						+ list.get(i).getLike_num() + ")'></li>";
			}
		}
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print(text);
	}
}
