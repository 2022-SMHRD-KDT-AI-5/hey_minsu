package Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.boardDAO;
import Model.boardDTO;
import Model.memberDTO;

public class BoardReviseService extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// 인코딩
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");

		// 기존 저장된 회원정보 session 호출
		HttpSession session = request.getSession();
		memberDTO info = (memberDTO) session.getAttribute("info");
		
		// title, content, division 값 받아오기
		String title = request.getParameter("title");
		String content = request.getParameter("content");
		int division = Integer.parseInt(request.getParameter("division"));
		int seq = Integer.parseInt(request.getParameter("seq"));
		
		// boardDTO, boardDAO 객체 불러오기
		boardDTO dto = new boardDTO(seq, info.getNum(), info.getId(), title, content, division);
		boardDAO dao = new boardDAO();
		
		boolean result = false;

		if (dao.update(dto) > 0) {
			// 게시글 수정 성공 시
			result = true;
		} else {
			// 게시글 수정 실패 시
			result = false;
		}

		PrintWriter out = response.getWriter();
		out.print(result);
	}
}
