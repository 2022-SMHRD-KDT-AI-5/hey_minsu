package Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.memberDAO;
import Model.memberDTO;

public class FindPwService extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 인코딩
		request.setCharacterEncoding("utf-8");

		// id, name, email 값 받아오기
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		
		// memberDTO, memberDAO 호출
		memberDTO dto = new memberDTO(id, name, email);
		memberDAO dao = new memberDAO();

		String id_check = null;
		
		if (dao.findpw(dto)) {
			// 비밀번호 찾기 성공 시
			id_check = id;
			HttpSession session = request.getSession();
			session.setAttribute("id_check", id_check);
		} else {
			// 비밀번호 찾기 실패 시
			id_check = null;
		}
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print(id_check);
	}
}
