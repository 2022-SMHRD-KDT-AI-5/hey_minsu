package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.boardDAO;
import Model.boardDTO;
import Model.memberDTO;

public class BoardSearchAdmin extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 인코딩
		request.setCharacterEncoding("UTF-8");

		
		response.setContentType("text/html;charset=UTF-8");
		
		String text = request.getParameter("text");
//		String column = request.getParameter("column");
//		if(column.equals("제목")) {
//			column = "board_title";
//		}else if(column.equals("글쓴이")) {
//			column = "mem_id";
//		}
		
		
		boardDAO dao = new boardDAO();
		ArrayList<boardDTO> list = dao.boardsearchadmin(text);
		
		HttpSession session = request.getSession();
		session.setAttribute("boardadmin", list.size());
		
		String result = "<div class='top'>"
					+ "<div class='num'>번호</div>"
					+ "<div class='title'>제목</div>"
					+ "<div class='writer'>글쓴이</div>"
					+ "<div class='date'>작성일</div>"
					+ "</div>";
		
		for(int i = 0; i < list.size(); i++) {
			result += "<div><div class='num'>" + (i + 1) + "</div>"
					+ "<div class='title'>" + "<a href='BoardRead.jsp?seq=" + list.get(i).getSeq() + "'>"
					+ list.get(i).getTitle() + "</a>" + "</div>"
					+ "<div class='writer'>" + list.get(i).getId() + "</div>"
					+ "<div class='date'>" + list.get(i).getDate() + "</div></div>";
		}
		PrintWriter out = response.getWriter();
		out.print(result);
	}
}

