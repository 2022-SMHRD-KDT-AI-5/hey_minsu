package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.boardDAO;
import Model.boardDTO;

public class BoardDeleteService extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int seq = Integer.parseInt(request.getParameter("seq"));
		
		boardDAO dao = new boardDAO();

		dao.delete(seq);
		
		response.sendRedirect("BoardReadMine.jsp");		
	}
}
