package Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.likeDAO;
import Model.likeDTO;
import Model.mapDAO;
import Model.mapDTO;
import Model.memberDTO;
import Model.pointDAO;

public class MapDeleteService extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 인코딩
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");

		// 필요한 정보 불러오기
		HttpSession session = request.getSession();
		memberDTO info = (memberDTO) session.getAttribute("info");
		int seq = Integer.parseInt(request.getParameter("seq"));

		likeDTO dto = new likeDTO(seq);
		likeDAO dao = new likeDAO();
		String point = dao.searchdelete(seq);

		mapDAO mdao = new mapDAO();

		
		boolean result = false;

		if (mdao.mapdelete(info.getId(), point) > 0) {
			result = true;
		}
		
		PrintWriter out = response.getWriter();
		out.print(result);
	}
}
