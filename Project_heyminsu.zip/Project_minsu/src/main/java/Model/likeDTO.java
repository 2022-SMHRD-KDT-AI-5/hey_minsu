package Model;

public class likeDTO {

	private int like_num;
	private int num;
	private String id;
	private String point;
	private int like_check;

	public likeDTO(int like_num, int num, String id, String point, int like_check) {
		this.like_num = like_num;
		this.num = num;
		this.id = id;
		this.point = point;
		this.like_check = like_check;
	}
	
	// 찜 목록 추가
	public likeDTO(int num, String id, String point) {
		this.num = num;
		this.id = id;
		this.point = point;
	}
	
	// 여행지 목록 추가
	public likeDTO(int num) {
		this.num = num;
	}
	
	public int getLike_num() {
		return like_num;
	}

	public void setLike_num(int like_num) {
		this.like_num = like_num;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPoint() {
		return point;
	}

	public void setPoint(String point) {
		this.point = point;
	}

	public int getLike_check() {
		return like_check;
	}

	public void setLike_check(int like_check) {
		this.like_check = like_check;
	}
}
