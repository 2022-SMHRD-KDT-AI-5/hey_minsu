package Model;

public class mapDTO {

	private int num;
	private String id;
	private String lat;
	private String lng;
	private String point;
	private String url;

	public mapDTO(int num, String id, String lat, String lng, String point, String url) {
		this.num = num;
		this.id = id;
		this.lat = lat;
		this.lng = lng;
		this.point = point;
		this.url = url;
	}

	public mapDTO(String lat, String lng, String point, String url) {
		this.lat = lat;
		this.lng = lng;
		this.point = point;
		this.url = url;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLng() {
		return lng;
	}

	public void setLng(String lng) {
		this.lng = lng;
	}

	public String getPoint() {
		return point;
	}

	public void setPoint(String point) {
		this.point = point;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
