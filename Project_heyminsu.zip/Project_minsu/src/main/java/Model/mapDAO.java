package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class mapDAO {
	
	// 지도에 띄울 목록을 데이터베이스에 연결하기 위한 DAO

	// 데이터베이스에서 사용되는 객체 선언
	Connection conn = null;
	PreparedStatement psmt = null;
	ResultSet rs = null;
	boolean result = false;
	int row = 0;
	String sql = "";

	// 데이터베이스 연결
	public void getConn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
			String user = "cgi_7_0704_1";
			String pw = "smhrd1";

			conn = DriverManager.getConnection(url, user, pw);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 임시 데이터베이스
//	public void getConn() {
//		try {
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//
//			String url = "jdbc:oracle:thin:@localhost:1521:xe";
//			String user = "hr";
//			String pw = "hr";
//
//			conn = DriverManager.getConnection(url, user, pw);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	// 데이터베이스 닫기
	public void close() {

		try {
			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 여행지도 목록 추가
	public int mapadd(mapDTO dto) {
		getConn();

		try {
			sql = "insert into mem_map values(?, ?, ?, ?, ?, ?)";
			psmt = conn.prepareStatement(sql);

			psmt.setInt(1, dto.getNum());
			psmt.setString(2, dto.getId());
			psmt.setString(3, dto.getLat());
			psmt.setString(4, dto.getLng());
			psmt.setString(5, dto.getPoint());
			psmt.setString(6, dto.getUrl());

			row = psmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return row;
	}
	
	// 여행지도 목록 삭제
	public int mapdelete(String id, String point) {
		getConn();

		try {
			sql = "delete from mem_map where mem_id = ? and point = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, id);
			psmt.setString(2, point);

			row = psmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return row;
	}
	
	// 여행지 위치 출력
	public ArrayList<mapDTO> mapping(String id) {
		getConn();
		
		ArrayList<mapDTO> list = new ArrayList<>();
		result = false;
		
		try {
			sql = "select * from mem_map where mem_id = ?";
			psmt = conn.prepareStatement(sql);
			
			psmt.setString(1, id);

			rs = psmt.executeQuery();
			
			while(rs.next()) {
				result = true;
				int mem_num = rs.getInt(1);
				String mem_id = rs.getString(2);
				String lat = rs.getString(3);
				String lng = rs.getString(4);
				String point = rs.getString(5);
				String url = rs.getString(6);
				
				mapDTO dto = new mapDTO(mem_num, mem_id, lat, lng, point, url);
				list.add(dto);
			}
			if(!result) {
				list = null;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
	}
}
