package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class likeDAO {

	// 찜목록을 데이터베이스에 연결하기 위한 DAO

	// 데이터베이스에서 사용되는 객체 선언
	Connection conn = null;
	PreparedStatement psmt = null;
	ResultSet rs = null;
	boolean result = false;
	int row = 0;
	String sql = "";

	// 데이터베이스 연결
	public void getConn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
			String user = "cgi_7_0704_1";
			String pw = "smhrd1";

			conn = DriverManager.getConnection(url, user, pw);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 임시 데이터베이스
//	public void getConn() {
//		try {
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//
//			String url = "jdbc:oracle:thin:@localhost:1521:xe";
//			String user = "hr";
//			String pw = "hr";
//
//			conn = DriverManager.getConnection(url, user, pw);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	// 데이터베이스 닫기
	public void close() {

		try {
			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 찜 목록 추가
	public int likeadd(likeDTO dto) {
		getConn();

		try {
			sql = "insert into mem_like values(mem_like_seq.nextval, ?, ?, ?, 0)";
			psmt = conn.prepareStatement(sql);

			psmt.setInt(1, dto.getNum());
			psmt.setString(2, dto.getId());
			psmt.setString(3, dto.getPoint());

			row = psmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return row;
	}
	
	public int likedelete(String seq) {
		getConn();

		ArrayList<likeDTO> list = new ArrayList<>();

		try {
			result = false;

			sql = "delete from mem_like where like_num = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, seq);

			row = psmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return row;
	}

	// 찜 목록 출력
	public ArrayList<likeDTO> likelist(String id) {
		getConn();

		ArrayList<likeDTO> list = new ArrayList<>();

		try {
			result = false;

			sql = "select * from mem_like where mem_id = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, id);

			rs = psmt.executeQuery();

			while (rs.next()) {
				result = true;
				int like_num = rs.getInt(1);
				int mem_num = rs.getInt(2);
				String mem_id = rs.getString(3);
				String point = rs.getString(4);
				int like_check = rs.getInt(5);

				likeDTO dto = new likeDTO(like_num, mem_num, mem_id, point, like_check);
				list.add(dto);
			}
			if (!result) {
				list = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
	}

	// 지도에 넣을 여행지 가져오기 및 체크
	public String pointadd(int seq) {
		getConn();
		
		String point = "";
		
		try {
			result = false;

			sql = "select point from mem_like where like_num = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setInt(1, seq);

			rs = psmt.executeQuery();

			while (rs.next()) {
				result = true;
				point = rs.getString(1);
				
				sql = "update mem_like set like_check = 1 where like_num = ?";
				psmt = conn.prepareStatement(sql);
				
				psmt.setInt(1, seq);
				
				row = psmt.executeUpdate();
			}
			if (!result || row == 0) {
				point = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return point;
	}
	
	// 지도에서 삭제 할 여행지 검색 및 체크 해제
	public String searchdelete(int seq) {
		getConn();
		
		String point = "";
		
		try {
			result = false;

			sql = "select point from mem_like where like_num = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setInt(1, seq);

			rs = psmt.executeQuery();

			while (rs.next()) {
				result = true;
				point = rs.getString(1);
				
				sql = "update mem_like set like_check = 0 where like_num = ?";
				psmt = conn.prepareStatement(sql);
				
				psmt.setInt(1, seq);
				
				row = psmt.executeUpdate();
			}
			if (!result || row == 0) {
				point = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return point;
	}
}
