package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class pointDAO {
	
	// 여행지 목록을 데이터베이스에 연결하기 위한 DAO

	// 데이터베이스에서 사용되는 객체 선언
	Connection conn = null;
	PreparedStatement psmt = null;
	ResultSet rs = null;
	boolean result = false;
	int row = 0;
	String sql = "";

	// 데이터베이스 연결
	public void getConn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
			String user = "cgi_7_0704_1";
			String pw = "smhrd1";

			conn = DriverManager.getConnection(url, user, pw);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 임시 데이터베이스
//	public void getConn() {
//		try {
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//
//			String url = "jdbc:oracle:thin:@localhost:1521:xe";
//			String user = "hr";
//			String pw = "hr";
//
//			conn = DriverManager.getConnection(url, user, pw);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	// 데이터베이스 닫기
	public void close() {

		try {
			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 여행지도에 담을 정보 검색
	public mapDTO searchpoint(String point) {
		getConn();
		
		String lat = null;
		String lng = null;
		String url = null;
		mapDTO mapdto = new mapDTO(lat, lng, point, url);
		
		try {
			result = false;

			sql = "select * from total where name = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, point);

			rs = psmt.executeQuery();

			while (rs.next()) {
				result = true;
				lat = rs.getString(2);
				lng = rs.getString(3);
				url = rs.getString(4);
				
				mapdto = new mapDTO(lat, lng, point, url);
			}
			if (!result) {
				mapdto = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return mapdto;
	}
}
