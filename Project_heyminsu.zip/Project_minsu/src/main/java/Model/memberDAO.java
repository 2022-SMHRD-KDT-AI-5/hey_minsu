package Model;

import java.sql.*;
import java.util.*;

import javax.servlet.http.HttpSession;

public class memberDAO {

	// 회원정보를 데이터베이스에 연결하기 위한 DAO

	// 데이터베이스에서 사용되는 객체 선언
	Connection conn = null;
	PreparedStatement psmt = null;
	ResultSet rs = null;
	boolean result = false;
	int row = 0;
	String sql = "";

	// 데이터베이스 연결
	public void getConn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
			String user = "cgi_7_0704_1";
			String pw = "smhrd1";

			conn = DriverManager.getConnection(url, user, pw);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 임시 데이터베이스
//	public void getConn() {
//		try {
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//
//			String url = "jdbc:oracle:thin:@localhost:1521:xe";
//			String user = "hr";
//			String pw = "hr";
//
//			conn = DriverManager.getConnection(url, user, pw);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	// 데이터베이스 닫기
	public void close() {

		try {
			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 회원가입
	public String join(memberDTO dto) {
		getConn();

		try {
			sql = "insert into mem_info values(mem_num_seq.nextval, ?, ?, ?, ?)";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, dto.getId());
			psmt.setString(2, dto.getPw());
			psmt.setString(3, dto.getName());
			psmt.setString(4, dto.getEmail());

			row = psmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return dto.getId();
	}
	
	// 회원가입 시 아이디 중복 확인
	public boolean checkid(String newid) {
		getConn();

		try {
			result = false;

			sql = "select * from mem_info where mem_id = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, newid);

			rs = psmt.executeQuery();

			if (rs.next()) {
				result = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return result;
	}
	
	// 로그인
	public memberDTO login(memberDTO dto) {
		getConn();

		try {
			result = false;

			sql = "select * from mem_info where mem_id = ? and mem_pw = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, dto.getId());
			psmt.setString(2, dto.getPw());

			rs = psmt.executeQuery();

			while (rs.next()) {
				result = true;
				dto.setNum(rs.getInt(1));
				dto.setId(rs.getString(2));
				dto.setPw(rs.getString(3));
				dto.setName(rs.getString(4));
				dto.setEmail(rs.getString(5));
			}
			if (!result) {
				dto = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return dto;
	}

	// 개인정보 확인
	public int check(memberDTO dto) {
		getConn();

		try {

			String origin_pw = "";
			row = 0;

			sql = "select mem_pw from mem_info where mem_num = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setInt(1, dto.getNum());

			rs = psmt.executeQuery();

			while (rs.next()) {
				origin_pw = rs.getString(1);
			}

			if (dto.getPw().equals(origin_pw)) {
				row = 1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return row;
	}

	// 개인정보 수정
	public int update(memberDTO dto) {
		getConn();

		try {
			sql = "update mem_info set mem_pw = ?, mem_name = ?, mem_email = ? where mem_id = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, dto.getPw());
			psmt.setString(2, dto.getName());
			psmt.setString(3, dto.getEmail());
			psmt.setString(4, dto.getId());

			row = psmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return row;
	}
	
	// 비밀번호 분실 후 수정
	public int updatepw(String id_check, String pw) {
		getConn();

		try {
			sql = "update mem_info set mem_pw = ? where mem_id = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, pw);
			psmt.setString(2, id_check);

			row = psmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return row;
	}

	// 아이디 분실 시
	public String findid(memberDTO dto) {
		getConn();

		String origin_id = null;

		try {

			sql = "select mem_id from mem_info where mem_name = ? and mem_email = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, dto.getName());
			psmt.setString(2, dto.getEmail());

			rs = psmt.executeQuery();

			while (rs.next()) {
				origin_id = rs.getString(1);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return origin_id;
	}

	// 비밀번호 분실 시
	public boolean findpw(memberDTO dto) {
		getConn();
		
		try {

			result = false;

			sql = "select * from mem_info where mem_id = ? and mem_name = ? and mem_email = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, dto.getId());
			psmt.setString(2, dto.getName());
			psmt.setString(3, dto.getEmail());

			rs = psmt.executeQuery();

			while(rs.next()) {
				result = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return result;
	}

	// 회원탈퇴
	public int resign(memberDTO dto) {
		getConn();

		try {

			String origin_pw = "";

			sql = "select mem_pw from mem_info where mem_id = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, dto.getId());

			rs = psmt.executeQuery();

			while (rs.next()) {
				origin_pw = rs.getString(1);
			}

			if (dto.getPw().equals(origin_pw)) {
				sql = "delete from mem_info where mem_id = ?";
				psmt = conn.prepareStatement(sql);

				psmt.setString(1, dto.getId());

				row = psmt.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return row;
	}
}
