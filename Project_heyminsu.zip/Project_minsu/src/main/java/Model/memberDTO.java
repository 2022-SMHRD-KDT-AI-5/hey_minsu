package Model;

public class memberDTO {

	// 회원 정보 관리 DTO

	private int num;
	private String id;
	private String pw;
	private String name;
	private String email;
	
	// 생성자 메소드 회원정보 저장
	public memberDTO(int num, String id, String pw, String name, String email) {
		this.num = num;
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.email = email;
	}

	// 생성자 메소드 회원가입, 회원정보 수정
	public memberDTO(String id, String pw, String name, String email) {
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.email = email;
	}

	// 생성자 메소드 로그인
	public memberDTO(String id, String pw) {
		this.id = id;
		this.pw = pw;
	}

	// 생성자 메소드 회원정보 확인
	public memberDTO(int num, String pw) {
		this.num = num;
		this.pw = pw;
	}
	
	// 생성자 메소드 회원정보 찾기
	public memberDTO(String id, String name, String email) {
		this.id = id;
		this.name = name;
		this.email = email;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
