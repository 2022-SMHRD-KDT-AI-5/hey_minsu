package Model;

public class boardDTO {

	// 게시판 관리 DTO

	private int seq;
	private int num;
	private String id;
	private String title;
	private String content;
	private String date;
	private int division;

	
	// 게시글 읽기, 게시글 목록
	public boardDTO(int seq, int num, String id, String title, String content, String date, int division) {
		this.seq = seq;
		this.num = num;
		this.id = id;
		this.title = title;
		this.content = content;
		this.date = date;
		this.division = division;
	}
	
	// 게시글 수정
	public boardDTO(int seq, int num, String id, String title, String content, int division) {
		this.seq = seq;
		this.num = num;
		this.id = id;
		this.title = title;
		this.content = content;
		this.division = division;
	}

	// 게시글 작성
	public boardDTO(int num, String id, String title, String content, int division) {
		this.num = num;
		this.id = id;
		this.title = title;
		this.content = content;
		this.division = division;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getDivision() {
		return division;
	}

	public void setDivision(int division) {
		this.division = division;
	}

}
