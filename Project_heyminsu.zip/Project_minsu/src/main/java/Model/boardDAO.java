package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

public class boardDAO {

	// 게시판을 데이터베이스에 연결하기 위한 DAO

	// 데이터베이스에서 사용되는 객체 선언
	Connection conn = null;
	PreparedStatement psmt = null;
	ResultSet rs = null;
	boolean result = false;
	int row = 0;
	String sql = "";

	// 데이터베이스 연결
	public void getConn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
			String user = "cgi_7_0704_1";
			String pw = "smhrd1";

			conn = DriverManager.getConnection(url, user, pw);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 임시 데이터베이스
//	public void getConn() {
//		try {
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//
//			String url = "jdbc:oracle:thin:@localhost:1521:xe";
//			String user = "hr";
//			String pw = "hr";
//
//			conn = DriverManager.getConnection(url, user, pw);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	// 데이터베이스 닫기
	public void close() {

		try {
			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 게시판 글 게시
	public int write(boardDTO dto) {
		getConn();

		try {
			sql = "insert into board values(board_num_seq.nextval, ?, ? ,?, ?, sysdate, ?)";
			psmt = conn.prepareStatement(sql);

			psmt.setInt(1, dto.getNum());
			psmt.setString(2, dto.getId());
			psmt.setString(3, dto.getTitle());
			psmt.setString(4, dto.getContent());
			psmt.setInt(5, dto.getDivision());

			row = psmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return row;
	}
	
	// 게시판 수정
	public int update(boardDTO dto) {
		getConn();

		try {
			sql = "update board set board_title = ?, board_content = ?, board_date = sysdate, user_admin = ? where board_num = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, dto.getTitle());
			psmt.setString(2, dto.getContent());
			psmt.setInt(3, dto.getDivision());
			psmt.setInt(4, dto.getSeq());

			row = psmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return row;
	}

	// 게시판 목록 출력
	public ArrayList<boardDTO> showboard(int x) {
		getConn();

		ArrayList<boardDTO> list = new ArrayList<>();

		try {
			result = false;

			sql = "select * from board where user_admin = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setInt(1, x);

			rs = psmt.executeQuery();

			while (rs.next()) {
				result = true;
				int seq = rs.getInt(1);
				int num = rs.getInt(2);
				String id = rs.getString(3);
				String title = rs.getString(4);
				String content = rs.getString(5);
				String date = rs.getString(6);
				int division = rs.getInt(7);

				boardDTO dto = new boardDTO(seq, num, id, title, content, date, division);
				list.add(dto);
			}
			if (!result) {
				list = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
	}

	// 게시판 내가 쓴 목록 출력
	public ArrayList<boardDTO> showmine(String mem_id) {
		getConn();

		ArrayList<boardDTO> list = new ArrayList<>();

		try {
			result = false;

			sql = "select * from board where mem_id = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, mem_id);

			rs = psmt.executeQuery();

			while (rs.next()) {
				result = true;
				int seq = rs.getInt(1);
				int num = rs.getInt(2);
				String id = rs.getString(3);
				String title = rs.getString(4);
				String content = rs.getString(5);
				String date = rs.getString(6);
				int division = rs.getInt(7);

				boardDTO dto = new boardDTO(seq, num, id, title, content, date, division);
				list.add(dto);
			}
			if (!result) {
				list = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
	}

	// 게시판 글 읽기
	public boardDTO read(int x) {
		getConn();

		boardDTO postone = null;

		try {
			result = false;

			sql = "select * from board where board_num = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setInt(1, x);

			rs = psmt.executeQuery();

			while (rs.next()) {
				result = true;
				int seq = rs.getInt(1);
				int num = rs.getInt(2);
				String id = rs.getString(3);
				String title = rs.getString(4);
				String content = rs.getString(5);
				String date = rs.getString(6);
				int division = rs.getInt(7);

				postone = new boardDTO(seq, num, id, title, content, date, division);
			}
			if (!result) {
				postone = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return postone;
	}

	// 게시판 글 삭제
	public int delete(int seq) {
		getConn();

		try {
			sql = "delete from board where board_num = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setInt(1, seq);

			row = psmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return row;
	}

	// 유저 게시판 글 검색
	public ArrayList<boardDTO> boardsearchuser(String text) {

		getConn();
		ArrayList<boardDTO> list = new ArrayList<>();

		try {
			sql = "select * from board where board_title like ? and user_admin = 0";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, "%" + text + "%");

			rs = psmt.executeQuery();

			while (rs.next()) {
				result = true;
				int seq = rs.getInt(1);
				int num = rs.getInt(2);
				String id = rs.getString(3);
				String title = rs.getString(4);
				String content = rs.getString(5);
				String date = rs.getString(6);
				int division = rs.getInt(7);

				boardDTO dto = new boardDTO(seq, num, id, title, content, date, division);
				list.add(dto);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
	}
	
	// 관리자 게시판 글 검색
	public ArrayList<boardDTO> boardsearchadmin(String text) {

		getConn();
		ArrayList<boardDTO> list = new ArrayList<>();

		try {
			sql = "select * from board where board_title like ? and user_admin = 1";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, "%" + text + "%");

			rs = psmt.executeQuery();

			while (rs.next()) {
				result = true;
				int seq = rs.getInt(1);
				int num = rs.getInt(2);
				String id = rs.getString(3);
				String title = rs.getString(4);
				String content = rs.getString(5);
				String date = rs.getString(6);
				int division = rs.getInt(7);

				boardDTO dto = new boardDTO(seq, num, id, title, content, date, division);
				list.add(dto);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
	}
	
	// 내가 쓴 글 검색
	public ArrayList<boardDTO> boardsearchmine(String text, String mem_id) {

		getConn();
		ArrayList<boardDTO> list = new ArrayList<>();

		try {
			sql = "select * from board where board_title like ? and mem_id = ?";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, "%" + text + "%");
			psmt.setString(2, mem_id);

			rs = psmt.executeQuery();

			while (rs.next()) {
				result = true;
				int seq = rs.getInt(1);
				int num = rs.getInt(2);
				String id = rs.getString(3);
				String title = rs.getString(4);
				String content = rs.getString(5);
				String date = rs.getString(6);
				int division = rs.getInt(7);

				boardDTO dto = new boardDTO(seq, num, id, title, content, date, division);
				list.add(dto);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
	}
}
